// R4.10.2.10_SHADOW_CANDIDATE_LEDGER_BETA2A: shadow candidate is persisted only inside the existing append-only hashed JSON payload.
import { createHash } from 'node:crypto';

import { buildShadowCandidateClassification } from './shadow-candidate-core.js';

import { prisma } from '@football-ai/database';

import {
  getCurrentScientificRecommendationMap,
  type CurrentScientificRecommendationAnalysis,
} from './current-scientific-recommendation-engine.js';
import { selectCurrentShadowCandidate } from './current-shadow-candidate-core.js';
import {
  CURRENT_SIGNAL_SNAPSHOT_LEDGER_VERSION,
  currentSignalCheckpointLabel,
  evaluateCurrentSignalSnapshotDue,
  nearestDueCheckpoint,
  parseCurrentSignalCheckpoints,
  type CurrentSignalAnalysisStatus,
  type CurrentSignalSnapshotAction,
} from './current-signal-snapshot-core.js';

interface ProviderFixtureRow {
  providerFixtureId: number;
  kickoffAt: Date;
  observedAt: Date;
}

interface ExistingSnapshotRow {
  id: number;
  providerFixtureId: number;
  checkpointMinutes: number;
  snapshotAsOf: Date;
  status: string;
  snapshotHash: string;
}

export interface CurrentSignalSnapshotPlanRow {
  providerFixtureId: number;
  kickoffAt: string;
  checkpointMinutes: number;
  checkpointLabel: string;
  exactMinutesToKickoff: number;
  distanceMinutes: number;
  analysisStatus: CurrentSignalAnalysisStatus;
  analysisError: string | null;
  action: CurrentSignalSnapshotAction;
  reason: string;
  existingSnapshotId: number | null;
  recommendation: CurrentScientificRecommendationAnalysis['recommendation'];
}

export interface CurrentSignalSnapshotPlan {
  version: string;
  now: string;
  checkpoints: number[];
  toleranceMinutes: number;
  fixturesConsidered: number;
  dueFixtures: number;
  rows: CurrentSignalSnapshotPlanRow[];
  externalApiCalled: false;
  databaseWritten: false;
  realMoneyExecution: false;
}

export interface CurrentSignalSnapshotCaptureResult {
  version: string;
  capturedAt: string;
  checkpoints: number[];
  toleranceMinutes: number;
  planned: number;
  inserted: number;
  duplicates: number;
  waiting: number;
  skipped: number;
  rows: Array<
    CurrentSignalSnapshotPlanRow & {
      insertedSnapshotId: number | null;
      insertedSnapshotHash: string | null;
      writeStatus: 'INSERTED' | 'DUPLICATE' | 'WAITING' | 'SKIPPED';
    }
  >;
  externalApiCalled: false;
  databaseWritten: boolean;
  realMoneyExecution: false;
}

function envInteger(name: string, fallback: number, minimum: number, maximum: number): number {
  const raw = process.env[name];

  if (raw == null || raw.trim() === '') {
    return fallback;
  }

  const value = Number(raw);

  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be an integer from ${minimum} to ${maximum}.`);
  }

  return value;
}

function envNumber(name: string, fallback: number, minimum: number, maximum: number): number {
  const raw = process.env[name];

  if (raw == null || raw.trim() === '') {
    return fallback;
  }

  const value = Number(raw);

  if (!Number.isFinite(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be a number from ${minimum} to ${maximum}.`);
  }

  return value;
}

function latestProviderFixtures(rows: ProviderFixtureRow[]): ProviderFixtureRow[] {
  const latest = new Map<number, ProviderFixtureRow>();

  for (const row of rows) {
    if (!latest.has(row.providerFixtureId)) {
      latest.set(row.providerFixtureId, row);
    }
  }

  return [...latest.values()];
}

function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(canonicalize);
  }

  if (value != null && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .sort((left, right): number => left[0].localeCompare(right[0]))
        .map(([key, item]) => [key, canonicalize(item)]),
    );
  }

  return value;
}

function snapshotHash(value: unknown): string {
  return createHash('sha256')
    .update(JSON.stringify(canonicalize(value)))
    .digest('hex');
}

function asDate(value: string | null | undefined): Date | null {
  if (value == null || value === '') {
    return null;
  }

  const date = new Date(value);

  return Number.isFinite(date.getTime()) ? date : null;
}

function isAnalysisStatus(value: string): value is CurrentSignalAnalysisStatus {
  return [
    'AVAILABLE',
    'NO_FRESH_PIT_ODDS',
    'NO_PROVIDER_FIXTURE_SNAPSHOT',
    'UNMAPPED_FIXTURE',
    'MAPPING_MISMATCH',
    'NO_MODEL',
    'NO_COMPLETE_MARKET',
    'NO_VALUE_SIGNAL',
  ].includes(value);
}

async function latestContextTimestamps(input: {
  localFixtureId: number | null;
  snapshotAsOf: Date;
}): Promise<{
  latestLineupCapturedAt: Date | null;
  latestInjuryCapturedAt: Date | null;
}> {
  if (input.localFixtureId == null) {
    return {
      latestLineupCapturedAt: null,
      latestInjuryCapturedAt: null,
    };
  }

  const [lineup, injury] = await Promise.all([
    prisma.fixtureLineupSnapshot.findFirst({
      where: {
        fixtureId: input.localFixtureId,
        capturedAt: {
          lte: input.snapshotAsOf,
        },
      },
      select: {
        capturedAt: true,
      },
      orderBy: {
        capturedAt: 'desc',
      },
    }),
    prisma.fixtureInjurySnapshot.findFirst({
      where: {
        fixtureId: input.localFixtureId,
        capturedAt: {
          lte: input.snapshotAsOf,
        },
      },
      select: {
        capturedAt: true,
      },
      orderBy: {
        capturedAt: 'desc',
      },
    }),
  ]);

  return {
    latestLineupCapturedAt: lineup?.capturedAt ?? null,
    latestInjuryCapturedAt: injury?.capturedAt ?? null,
  };
}

async function loadDueProviderFixtures(input: {
  now: Date;
  checkpoints: number[];
  toleranceMinutes: number;
  providerFixtureIds?: number[];
  maximumFixtures: number;
}): Promise<
  Array<
    ProviderFixtureRow & {
      checkpointMinutes: number;
      exactMinutesToKickoff: number;
      distanceMinutes: number;
    }
  >
> {
  const maximumCheckpoint = Math.max(...input.checkpoints);

  const providerFilter =
    input.providerFixtureIds == null
      ? undefined
      : {
          in: [
            ...new Set(
              input.providerFixtureIds.filter(
                (value: number): boolean => Number.isSafeInteger(value) && value > 0,
              ),
            ),
          ],
        };

  const latestKickoff = new Date(
    input.now.getTime() + (maximumCheckpoint + input.toleranceMinutes + 2) * 60_000,
  );

  const rows = (await prisma.apiFootballFixtureSnapshot.findMany({
    where: {
      providerFixtureId: providerFilter,
      kickoffAt: {
        gt: input.now,
        lte: latestKickoff,
      },
    },
    select: {
      providerFixtureId: true,
      kickoffAt: true,
      observedAt: true,
    },
    orderBy: [
      {
        observedAt: 'desc',
      },
      {
        id: 'desc',
      },
    ],
    take: input.maximumFixtures * 12,
  })) as ProviderFixtureRow[];

  return latestProviderFixtures(rows)
    .map((row: ProviderFixtureRow) => {
      const due = nearestDueCheckpoint({
        kickoffAt: row.kickoffAt,
        now: input.now,
        checkpoints: input.checkpoints,
        toleranceMinutes: input.toleranceMinutes,
      });

      return due == null
        ? null
        : {
            ...row,
            checkpointMinutes: due.checkpointMinutes,
            exactMinutesToKickoff: due.exactMinutesToKickoff,
            distanceMinutes: due.distanceMinutes,
          };
    })
    .filter(
      (
        row,
      ): row is ProviderFixtureRow & {
        checkpointMinutes: number;
        exactMinutesToKickoff: number;
        distanceMinutes: number;
      } => row != null,
    )
    .sort(
      (left, right): number =>
        left.kickoffAt.getTime() - right.kickoffAt.getTime() ||
        right.checkpointMinutes - left.checkpointMinutes,
    )
    .slice(0, input.maximumFixtures);
}

export async function planDueCurrentSignalSnapshots(
  input: {
    now?: Date;
    providerFixtureIds?: number[];
    checkpoints?: number[];
    toleranceMinutes?: number;
    maximumFixtures?: number;
  } = {},
): Promise<CurrentSignalSnapshotPlan> {
  const now = input.now ?? new Date();

  const checkpoints = input.checkpoints ?? parseCurrentSignalCheckpoints();

  const toleranceMinutes =
    input.toleranceMinutes ?? envNumber('CURRENT_SIGNAL_SNAPSHOT_TOLERANCE_MINUTES', 2, 0.25, 10);

  const maximumFixtures =
    input.maximumFixtures ?? envInteger('CURRENT_SIGNAL_SNAPSHOT_MAX_FIXTURES', 100, 1, 300);

  const dueFixtures = await loadDueProviderFixtures({
    now,
    checkpoints,
    toleranceMinutes,
    providerFixtureIds: input.providerFixtureIds,
    maximumFixtures,
  });

  const dueProviderFixtureIds = dueFixtures.map((row): number => row.providerFixtureId);

  const existingRows =
    dueProviderFixtureIds.length === 0
      ? []
      : ((await prisma.scientificCurrentSignalSnapshot.findMany({
          where: {
            providerFixtureId: {
              in: dueProviderFixtureIds,
            },
            checkpointMinutes: {
              in: checkpoints,
            },
          },
          select: {
            id: true,
            providerFixtureId: true,
            checkpointMinutes: true,
            snapshotAsOf: true,
            status: true,
            snapshotHash: true,
          },
        })) as ExistingSnapshotRow[]);

  const existingByKey = new Map<string, ExistingSnapshotRow>(
    existingRows.map((row: ExistingSnapshotRow) => [
      `${row.providerFixtureId}:${row.checkpointMinutes}`,
      row,
    ]),
  );

  const analysisByFixture =
    dueProviderFixtureIds.length === 0
      ? new Map()
      : await getCurrentScientificRecommendationMap({
          providerFixtureIds: dueProviderFixtureIds,
          now,
          maxFixtures: maximumFixtures,
        });

  const rows: CurrentSignalSnapshotPlanRow[] = [];

  for (const fixture of dueFixtures) {
    const analysis = analysisByFixture.get(fixture.providerFixtureId);

    if (analysis == null || !isAnalysisStatus(analysis.status)) {
      rows.push({
        providerFixtureId: fixture.providerFixtureId,
        kickoffAt: fixture.kickoffAt.toISOString(),
        checkpointMinutes: fixture.checkpointMinutes,
        checkpointLabel: currentSignalCheckpointLabel(fixture.checkpointMinutes),
        exactMinutesToKickoff: fixture.exactMinutesToKickoff,
        distanceMinutes: fixture.distanceMinutes,
        analysisStatus: 'NO_MODEL',
        analysisError: 'CURRENT_ANALYSIS_NOT_RETURNED',
        action: 'WAIT_FOR_DATA',
        reason: 'CURRENT_ANALYSIS_NOT_RETURNED',
        existingSnapshotId: null,
        recommendation: null,
      });

      continue;
    }

    const existing =
      existingByKey.get(`${fixture.providerFixtureId}:${fixture.checkpointMinutes}`) ?? null;

    const due = evaluateCurrentSignalSnapshotDue({
      kickoffAt: fixture.kickoffAt,
      now,
      checkpoints,
      toleranceMinutes,
      status: analysis.status,
      alreadyCaptured: existing != null,
    });

    rows.push({
      providerFixtureId: fixture.providerFixtureId,
      kickoffAt: fixture.kickoffAt.toISOString(),
      checkpointMinutes: fixture.checkpointMinutes,
      checkpointLabel: currentSignalCheckpointLabel(fixture.checkpointMinutes),
      exactMinutesToKickoff: fixture.exactMinutesToKickoff,
      distanceMinutes: fixture.distanceMinutes,
      analysisStatus: analysis.status,
      analysisError: analysis.error,
      action: due.action,
      reason: due.reason,
      existingSnapshotId: existing?.id ?? null,
      recommendation: analysis.recommendation,
    });
  }

  return {
    version: CURRENT_SIGNAL_SNAPSHOT_LEDGER_VERSION,
    now: now.toISOString(),
    checkpoints,
    toleranceMinutes,
    fixturesConsidered: dueFixtures.length,
    dueFixtures: rows.length,
    rows,
    externalApiCalled: false,
    databaseWritten: false,
    realMoneyExecution: false,
  };
}

async function analysisForCapture(input: {
  providerFixtureId: number;
  now: Date;
}): Promise<CurrentScientificRecommendationAnalysis | null> {
  const map = await getCurrentScientificRecommendationMap({
    providerFixtureIds: [input.providerFixtureId],
    now: input.now,
    maxFixtures: 1,
  });

  return map.get(input.providerFixtureId) ?? null;
}

// R4103331_PERSISTED_PAYLOAD_HASH_AUTHORITY
export function prepareCurrentSignalSnapshotPayloadForPersistence(value: unknown): {
  persistedPayload: unknown;
  snapshotHash: string;
} {
  const persistedPayload = JSON.parse(JSON.stringify(value)) as unknown;

  return {
    persistedPayload,
    snapshotHash: snapshotHash(persistedPayload),
  };
}

async function createSnapshot(input: { plan: CurrentSignalSnapshotPlanRow; now: Date }): Promise<{
  id: number;
  snapshotHash: string;
}> {
  const analysis = await analysisForCapture({
    providerFixtureId: input.plan.providerFixtureId,
    now: input.now,
  });

  if (analysis == null || !isAnalysisStatus(analysis.status)) {
    throw new Error(`Current analysis unavailable for fixture ${input.plan.providerFixtureId}.`);
  }

  const recommendation = analysis.recommendation;

  const snapshotAsOf = new Date(analysis.calculatedAt);

  const kickoffAt = new Date(analysis.kickoffAt);

  const context = await latestContextTimestamps({
    localFixtureId: analysis.localFixtureId,
    snapshotAsOf,
  });

  const candidateCount = analysis.candidates.length;

  const currentEligibleCandidateCount = analysis.candidates.filter(
    (candidate): boolean => candidate.currentSignalEligible,
  ).length;

  const officialEligibleCandidateCount = analysis.candidates.filter(
    (candidate): boolean => candidate.officialEligible,
  ).length;

  const shadowCandidateDecision = selectCurrentShadowCandidate(
    analysis.candidates as readonly unknown[],
  );

  // R4.10.2.10_SHADOW_CANDIDATE_DAILY_LEDGER
  const shadowCandidate = buildShadowCandidateClassification({
    providerFixtureId: analysis.providerFixtureId,
    checkpointMinutes: input.plan.checkpointMinutes,
    calculatedAt: analysis.calculatedAt,
    analysisStatus: analysis.status,
    candidates: analysis.candidates,
  });

  const payload = {
    paperShadowRecommendation: analysis.paperShadowRecommendation,
    shadowCandidate,
    ledgerVersion: CURRENT_SIGNAL_SNAPSHOT_LEDGER_VERSION,
    checkpoint: {
      minutes: input.plan.checkpointMinutes,
      label: input.plan.checkpointLabel,
      exactMinutesToKickoff: input.plan.exactMinutesToKickoff,
      toleranceReason: input.plan.reason,
    },
    analysis,
    shadowCandidateDecision,
    context: {
      latestLineupCapturedAt: context.latestLineupCapturedAt?.toISOString() ?? null,
      latestInjuryCapturedAt: context.latestInjuryCapturedAt?.toISOString() ?? null,
    },
    integrity: {
      appendOnly: true,
      officialBestBetChanged: false,
      noFutureBackfill: true,
      externalApiCalled: false,
      automaticBetPlacement: false,
      realMoneyExecution: false,
    },
  };

  const preparedPayload = prepareCurrentSignalSnapshotPayloadForPersistence(payload);

  const hash = preparedPayload.snapshotHash;

  try {
    const created = await prisma.scientificCurrentSignalSnapshot.create({
      data: {
        providerFixtureId: analysis.providerFixtureId,
        localFixtureId: analysis.localFixtureId,
        checkpointMinutes: input.plan.checkpointMinutes,
        checkpointLabel: input.plan.checkpointLabel,
        actualHorizonMinutes: analysis.horizonMinutes,
        snapshotAsOf,
        kickoffAt,
        status: analysis.status,
        selectedMarket: recommendation?.marketType ?? null,
        selectedSelection: recommendation?.selection ?? null,
        lineValue: recommendation?.lineValue ?? null,
        decimalOdds: recommendation?.decimalOdds ?? null,
        bookmakerName: recommendation?.bookmakerName ?? null,
        modelProbability: recommendation?.modelProbability ?? null,
        fairMarketProbability: recommendation?.fairMarketProbability ?? null,
        impliedProbability: recommendation == null ? null : 1 / recommendation.decimalOdds,
        edge: recommendation?.edge ?? null,
        expectedValue: recommendation?.expectedValue ?? null,
        reliabilityStatus: recommendation?.reliabilityStatus ?? null,
        modelSource: recommendation?.modelSource ?? null,
        modelFallbackReason: recommendation?.modelFallbackReason ?? null,
        modelConfidenceTier: recommendation?.modelConfidenceTier ?? null,
        modelHistorySampleSize: recommendation?.modelHistorySampleSize ?? null,
        dataQualityScore: recommendation?.dataQualityScore ?? null,
        modelVersion: recommendation?.modelVersion ?? null,
        sourceOddsSnapshotId: recommendation?.sourceOddsSnapshotId ?? null,
        sourceOddsUpdatedAt: asDate(recommendation?.sourceOddsUpdatedAt),
        sourceOddsFirstObservedAt: asDate(recommendation?.sourceOddsFirstObservedAt),
        sourceOddsReobservedAt: asDate(recommendation?.sourceOddsReobservedAt),
        sourceOddsFreshnessAt: asDate(recommendation?.sourceOddsFreshnessAt),
        oddsFreshnessBasis: recommendation?.oddsFreshnessBasis ?? null,
        reobservationRawSnapshotId: recommendation?.reobservationRawSnapshotId ?? null,
        latestLineupCapturedAt: context.latestLineupCapturedAt,
        latestInjuryCapturedAt: context.latestInjuryCapturedAt,
        candidateCount,
        currentEligibleCandidateCount,
        officialEligibleCandidateCount,
        analysisPayload: preparedPayload.persistedPayload,
        snapshotHash: hash,
      },
      select: {
        id: true,
        snapshotHash: true,
      },
    });

    return created;
  } catch (error) {
    const code = (
      error as {
        code?: string;
      }
    ).code;

    if (code === 'P2002') {
      const existing = await prisma.scientificCurrentSignalSnapshot.findUnique({
        where: {
          providerFixtureId_checkpointMinutes: {
            providerFixtureId: analysis.providerFixtureId,
            checkpointMinutes: input.plan.checkpointMinutes,
          },
        },
        select: {
          id: true,
          snapshotHash: true,
        },
      });

      if (existing != null) {
        return existing;
      }
    }

    throw error;
  }
}

export async function captureDueCurrentSignalSnapshots(
  input: {
    now?: Date;
    providerFixtureIds?: number[];
    checkpoints?: number[];
    toleranceMinutes?: number;
    maximumFixtures?: number;
  } = {},
): Promise<CurrentSignalSnapshotCaptureResult> {
  const now = input.now ?? new Date();

  const plan = await planDueCurrentSignalSnapshots({
    ...input,
    now,
  });

  const rows: CurrentSignalSnapshotCaptureResult['rows'] = [];

  let inserted = 0;
  let duplicates = 0;
  let waiting = 0;
  let skipped = 0;

  for (const row of plan.rows) {
    if (row.action === 'WAIT_FOR_DATA') {
      waiting += 1;

      rows.push({
        ...row,
        insertedSnapshotId: null,
        insertedSnapshotHash: null,
        writeStatus: 'WAITING',
      });

      continue;
    }

    if (row.action === 'ALREADY_CAPTURED' || row.action === 'NOT_DUE') {
      skipped += 1;

      rows.push({
        ...row,
        insertedSnapshotId: row.existingSnapshotId,
        insertedSnapshotHash: null,
        writeStatus: 'SKIPPED',
      });

      continue;
    }

    const before = await prisma.scientificCurrentSignalSnapshot.findUnique({
      where: {
        providerFixtureId_checkpointMinutes: {
          providerFixtureId: row.providerFixtureId,
          checkpointMinutes: row.checkpointMinutes,
        },
      },
      select: {
        id: true,
        snapshotHash: true,
      },
    });

    if (before != null) {
      duplicates += 1;

      rows.push({
        ...row,
        insertedSnapshotId: before.id,
        insertedSnapshotHash: before.snapshotHash,
        writeStatus: 'DUPLICATE',
      });

      continue;
    }

    const created = await createSnapshot({
      plan: row,
      now,
    });

    inserted += 1;

    rows.push({
      ...row,
      insertedSnapshotId: created.id,
      insertedSnapshotHash: created.snapshotHash,
      writeStatus: 'INSERTED',
    });
  }

  return {
    version: CURRENT_SIGNAL_SNAPSHOT_LEDGER_VERSION,
    capturedAt: now.toISOString(),
    checkpoints: plan.checkpoints,
    toleranceMinutes: plan.toleranceMinutes,
    planned: plan.rows.length,
    inserted,
    duplicates,
    waiting,
    skipped,
    rows,
    externalApiCalled: false,
    databaseWritten: inserted > 0,
    realMoneyExecution: false,
  };
}

export async function getCurrentSignalSnapshotEvidence(
  input: {
    providerFixtureId?: number;
    limit?: number;
  } = {},
): Promise<{
  version: string;
  totalRows: number;
  rows: unknown[];
  externalApiCalled: false;
  databaseWritten: false;
  realMoneyExecution: false;
}> {
  const limit = Math.max(1, Math.min(1000, input.limit ?? 200));

  const rows = await prisma.scientificCurrentSignalSnapshot.findMany({
    where:
      input.providerFixtureId == null
        ? undefined
        : {
            providerFixtureId: input.providerFixtureId,
          },
    orderBy: [
      {
        snapshotAsOf: 'desc',
      },
      {
        id: 'desc',
      },
    ],
    take: limit,
  });

  const totalRows = await prisma.scientificCurrentSignalSnapshot.count({
    where:
      input.providerFixtureId == null
        ? undefined
        : {
            providerFixtureId: input.providerFixtureId,
          },
  });

  return {
    version: CURRENT_SIGNAL_SNAPSHOT_LEDGER_VERSION,
    totalRows,
    rows,
    externalApiCalled: false,
    databaseWritten: false,
    realMoneyExecution: false,
  };
}

export async function getCurrentSignalSnapshotCoverage(): Promise<{
  version: string;
  totalRows: number;
  fixtures: number;
  available: number;
  noValue: number;
  fallbackRows: number;
  officialEligibleCandidateRows: number;
  byCheckpoint: Array<{
    checkpointMinutes: number;
    rows: number;
  }>;
  externalApiCalled: false;
  databaseWritten: false;
}> {
  const [
    totalRows,
    available,
    noValue,
    fallbackRows,
    grouped,
    fixtureRows,
    officialEligibleCandidateRows,
  ] = await Promise.all([
    prisma.scientificCurrentSignalSnapshot.count(),
    prisma.scientificCurrentSignalSnapshot.count({
      where: {
        status: 'AVAILABLE',
      },
    }),
    prisma.scientificCurrentSignalSnapshot.count({
      where: {
        status: 'NO_VALUE_SIGNAL',
      },
    }),
    prisma.scientificCurrentSignalSnapshot.count({
      where: {
        modelSource: 'SCIENTIFIC_BASELINE_FALLBACK',
      },
    }),
    prisma.scientificCurrentSignalSnapshot.groupBy({
      by: ['checkpointMinutes'],
      _count: {
        _all: true,
      },
      orderBy: {
        checkpointMinutes: 'desc',
      },
    }),
    prisma.scientificCurrentSignalSnapshot.findMany({
      select: {
        providerFixtureId: true,
      },
      distinct: ['providerFixtureId'],
    }),
    prisma.scientificCurrentSignalSnapshot.count({
      where: {
        officialEligibleCandidateCount: {
          gt: 0,
        },
      },
    }),
  ]);

  return {
    version: CURRENT_SIGNAL_SNAPSHOT_LEDGER_VERSION,
    totalRows,
    fixtures: fixtureRows.length,
    available,
    noValue,
    fallbackRows,
    officialEligibleCandidateRows,
    byCheckpoint: grouped.map(
      (row: {
        checkpointMinutes: number;
        _count: {
          _all: number;
        };
      }) => ({
        checkpointMinutes: row.checkpointMinutes,
        rows: row._count._all,
      }),
    ),
    externalApiCalled: false,
    databaseWritten: false,
  };
}
