import { randomUUID } from 'node:crypto';

import { prisma, type InputJsonValue } from '@football-ai/database';
import { apiFootballGet, type ApiFootballRequestResult } from './api-football-client.js';
import {
  apiFootballTimezone,
  normalizeApiFootballFixtures,
  normalizeApiFootballPrematchOdds,
  parseCommaSeparatedIds,
  type ApiFootballQuotaSnapshot,
  type NormalizedApiFootballFixture,
} from './api-football-contract.js';
import { discoverApiFootballLeagueProfile } from './api-football-provider-engine.js';
import { deterministicHash } from './scientific-evaluation-contract.js';
import {
  FRESH_ODDS_COLLECTOR_VERSION,
  classifyFreshOddsWindow,
  evaluateFreshOddsQuota,
  freshOddsDueAt,
  freshOddsHorizonLabel,
  isClosingProxyHorizon,
  parseFreshOddsHorizons,
  sourceAgeMinutes,
  summarizeSourceAges,
  type FreshOddsQuotaObservation,
} from './fresh-odds-collector-core.js';

const TERMINAL_STATUSES = ['SUCCESS', 'EMPTY', 'FAILED', 'SKIPPED'] as const;

type CheckpointStatus = 'PENDING' | 'RUNNING' | 'SUCCESS' | 'EMPTY' | 'RETRY' | 'FAILED' | 'SKIPPED';

interface FreshOddsConfig {
  horizonsMinutes: number[];
  leadMinutes: number;
  toleranceMinutes: number;
  retryMinutes: number;
  maximumAttempts: number;
  maximumDuePerTick: number;
  lockMinutes: number;
  dailyReserve: number;
  minuteReserve: number;
  planDaysAhead: number;
  maximumTrackedFixtures: number;
}

interface DueCheckpoint {
  id: number;
  providerFixtureId: number;
  providerLeagueId: number;
  season: number;
  kickoffAt: Date;
  horizonMinutes: number;
  horizonLabel: string;
  dueAt: Date;
  status: string;
  attempts: number;
  nextRetryAt: Date | null;
  updatedAt: Date;
}

function jsonValue(value: unknown): InputJsonValue {
  return JSON.parse(JSON.stringify(value)) as InputJsonValue;
}

function integerEnv(name: string, fallback: number, minimum = 0): number {
  const raw = process.env[name];
  if (raw == null || raw.trim() === '') return fallback;
  const value = Number(raw);
  if (!Number.isInteger(value) || value < minimum) throw new Error(`${name} must be an integer >= ${minimum}.`);
  return value;
}

function booleanEnv(name: string, fallback: boolean): boolean {
  const raw = process.env[name];
  if (raw == null || raw.trim() === '') return fallback;
  const normalized = raw.trim().toLowerCase();
  if (['1', 'true', 'yes', 'on'].includes(normalized)) return true;
  if (['0', 'false', 'no', 'off'].includes(normalized)) return false;
  throw new Error(`${name} must be true or false.`);
}

function config(): FreshOddsConfig {
  return {
    horizonsMinutes: parseFreshOddsHorizons(),
    leadMinutes: integerEnv('FRESH_ODDS_DUE_LEAD_MINUTES', 1, 0),
    toleranceMinutes: integerEnv('FRESH_ODDS_DUE_TOLERANCE_MINUTES', 8, 1),
    retryMinutes: integerEnv('FRESH_ODDS_RETRY_MINUTES', 2, 1),
    maximumAttempts: integerEnv('FRESH_ODDS_MAX_ATTEMPTS', 3, 1),
    maximumDuePerTick: integerEnv('FRESH_ODDS_MAX_DUE_PER_TICK', 12, 1),
    lockMinutes: integerEnv('FRESH_ODDS_LOCK_MINUTES', 10, 1),
    dailyReserve: integerEnv('FRESH_ODDS_DAILY_REQUEST_RESERVE', 500, 0),
    minuteReserve: integerEnv('FRESH_ODDS_MINUTE_REQUEST_RESERVE', 5, 0),
    planDaysAhead: integerEnv('FRESH_ODDS_PLAN_DAYS_AHEAD', 2, 1),
    maximumTrackedFixtures: integerEnv('FRESH_ODDS_MAX_TRACKED_FIXTURES', 1000, 1),
  };
}

function fixtureRawItem(payload: unknown, providerFixtureId: number): unknown {
  const envelope = payload != null && typeof payload === 'object' ? (payload as Record<string, unknown>) : null;
  const response = Array.isArray(envelope?.response) ? envelope.response : [];
  return response.find((item) => {
    if (item == null || typeof item !== 'object') return false;
    const fixture = (item as Record<string, unknown>).fixture;
    return fixture != null && typeof fixture === 'object' && Number((fixture as Record<string, unknown>).id) === providerFixtureId;
  }) ?? null;
}

async function persistFixtureRequest(request: ApiFootballRequestResult): Promise<{ normalized: number; inserted: number }> {
  const fixtures = normalizeApiFootballFixtures(request.payload);
  let inserted = 0;
  for (const fixture of fixtures) {
    const rawPayload = fixtureRawItem(request.payload, fixture.providerFixtureId);
    const payloadHash = deterministicHash('API_FOOTBALL_FIXTURE_SNAPSHOT', {
      providerFixtureId: fixture.providerFixtureId,
      providerLeagueId: fixture.providerLeagueId,
      season: fixture.season,
      kickoffAt: fixture.kickoffAt.toISOString(),
      statusShort: fixture.statusShort,
      homeProviderTeamId: fixture.homeProviderTeamId,
      awayProviderTeamId: fixture.awayProviderTeamId,
      homeTeamName: fixture.homeTeamName,
      awayTeamName: fixture.awayTeamName,
      homeGoals: fixture.homeGoals,
      awayGoals: fixture.awayGoals,
      fulltimeHomeGoals: fixture.fulltimeHomeGoals,
      fulltimeAwayGoals: fixture.fulltimeAwayGoals,
      rawPayload,
    });
    const result = await prisma.apiFootballFixtureSnapshot.createMany({
      data: [{
        providerFixtureId: fixture.providerFixtureId,
        providerLeagueId: fixture.providerLeagueId,
        season: fixture.season,
        kickoffAt: fixture.kickoffAt,
        statusShort: fixture.statusShort,
        homeProviderTeamId: fixture.homeProviderTeamId,
        awayProviderTeamId: fixture.awayProviderTeamId,
        homeTeamName: fixture.homeTeamName,
        awayTeamName: fixture.awayTeamName,
        homeGoals: fixture.homeGoals,
        awayGoals: fixture.awayGoals,
        fulltimeHomeGoals: fixture.fulltimeHomeGoals,
        fulltimeAwayGoals: fixture.fulltimeAwayGoals,
        observedAt: request.observedAt,
        rawPayload: jsonValue(rawPayload),
        payloadHash,
      }],
      skipDuplicates: true,
    });
    inserted += result.count;
  }
  return { normalized: fixtures.length, inserted };
}

async function persistRawOddsRequest(input: { request: ApiFootballRequestResult; checkpoint: DueCheckpoint }): Promise<number> {
  const payloadHash = deterministicHash('API_FOOTBALL_DATA_SNAPSHOT', {
    kind: 'FRESH_PREMATCH_ODDS_HORIZON',
    providerFixtureId: input.checkpoint.providerFixtureId,
    providerLeagueId: input.checkpoint.providerLeagueId,
    sourceAsOf: input.request.observedAt.toISOString(),
    query: input.request.query,
    payload: input.request.payload,
    horizonMinutes: input.checkpoint.horizonMinutes,
    horizonLabel: input.checkpoint.horizonLabel,
  });
  const result = await prisma.apiFootballDataSnapshot.createMany({
    data: [{
      kind: 'FRESH_PREMATCH_ODDS_HORIZON',
      providerFixtureId: input.checkpoint.providerFixtureId,
      providerLeagueId: input.checkpoint.providerLeagueId,
      sourceAsOf: input.request.observedAt,
      observedAt: input.request.observedAt,
      queryPayload: jsonValue({ ...input.request.query, horizonMinutes: input.checkpoint.horizonMinutes, horizonLabel: input.checkpoint.horizonLabel }),
      rawPayload: jsonValue(input.request.payload),
      payloadHash,
    }],
    skipDuplicates: true,
  });
  return result.count;
}

async function persistOdds(input: { request: ApiFootballRequestResult; checkpoint: DueCheckpoint }): Promise<{
  normalized: number;
  inserted: number;
  pitUsable: number;
  sourceAgeSummary: ReturnType<typeof summarizeSourceAges>;
}> {
  const rows = normalizeApiFootballPrematchOdds(input.request.payload, input.request.observedAt);
  let inserted = 0;
  for (const row of rows) {
    const payloadHash = deterministicHash('API_FOOTBALL_FRESH_ODDS_SNAPSHOT', {
      providerFixtureId: row.providerFixtureId,
      providerLeagueId: row.providerLeagueId,
      season: row.season,
      kickoffAt: row.kickoffAt.toISOString(),
      sourceUpdatedAt: row.sourceUpdatedAt?.toISOString() ?? null,
      bookmakerId: row.bookmakerId,
      bookmakerName: row.bookmakerName,
      betId: row.betId,
      betName: row.betName,
      marketType: row.marketType,
      selection: row.selection,
      lineValue: row.lineValue,
      decimalOdds: row.decimalOdds,
      observedAt: row.observedAt.toISOString(),
      horizonMinutes: input.checkpoint.horizonMinutes,
      horizonLabel: input.checkpoint.horizonLabel,
    });
    const result = await prisma.apiFootballOddsSnapshot.createMany({
      data: [{
        providerFixtureId: row.providerFixtureId,
        providerLeagueId: row.providerLeagueId,
        season: row.season,
        kickoffAt: row.kickoffAt,
        sourceUpdatedAt: row.sourceUpdatedAt,
        observedAt: row.observedAt,
        bookmakerId: row.bookmakerId,
        bookmakerName: row.bookmakerName,
        betId: row.betId,
        betName: row.betName,
        marketType: row.marketType,
        selection: row.selection,
        lineValue: row.lineValue,
        decimalOdds: row.decimalOdds,
        pitUsable: row.pitUsable,
        payloadHash,
      }],
      skipDuplicates: true,
    });
    inserted += result.count;
  }
  const ages = rows.map((row) => sourceAgeMinutes({ observedAt: row.observedAt, sourceUpdatedAt: row.sourceUpdatedAt }));
  return {
    normalized: rows.length,
    inserted,
    pitUsable: rows.filter((row) => row.pitUsable).length,
    sourceAgeSummary: summarizeSourceAges(ages),
  };
}

function quotaObservation(quota: ApiFootballQuotaSnapshot | null): FreshOddsQuotaObservation | null {
  if (quota == null) return null;
  return {
    requestsRemainingDay: quota.requestsRemainingDay,
    rateRemainingPerMinute: quota.rateRemainingPerMinute,
  };
}

function quotaFromJson(value: unknown): ApiFootballQuotaSnapshot | null {
  if (value == null || typeof value !== 'object' || Array.isArray(value)) return null;
  const row = value as Record<string, unknown>;
  const numberOrNull = (key: string): number | null => {
    const raw = row[key];
    const parsed = typeof raw === 'number' ? raw : typeof raw === 'string' ? Number(raw) : Number.NaN;
    return Number.isFinite(parsed) ? parsed : null;
  };
  return {
    requestsLimitDay: numberOrNull('requestsLimitDay'),
    requestsRemainingDay: numberOrNull('requestsRemainingDay'),
    rateLimitPerMinute: numberOrNull('rateLimitPerMinute'),
    rateRemainingPerMinute: numberOrNull('rateRemainingPerMinute'),
  };
}

async function latestKnownQuota(): Promise<ApiFootballQuotaSnapshot | null> {
  const checkpoint = await prisma.apiFootballFreshOddsCheckpoint.findFirst({
    where: { OR: [{ quotaRemainingDay: { not: null } }, { quotaRemainingMinute: { not: null } }] },
    orderBy: [{ attemptedAt: 'desc' }, { updatedAt: 'desc' }],
    select: { quotaRemainingDay: true, quotaRemainingMinute: true },
  });
  if (checkpoint?.quotaRemainingDay != null || checkpoint?.quotaRemainingMinute != null) {
    return {
      requestsLimitDay: null,
      requestsRemainingDay: checkpoint.quotaRemainingDay,
      rateLimitPerMinute: null,
      rateRemainingPerMinute: checkpoint.quotaRemainingMinute,
    };
  }
  const run = await prisma.apiFootballProviderRun.findFirst({
    orderBy: { startedAt: 'desc' },
    select: { quotaAfter: true },
  });
  return quotaFromJson(run?.quotaAfter ?? null);
}

function quotaAllowed(quota: ApiFootballQuotaSnapshot | null, cfg: FreshOddsConfig) {
  return evaluateFreshOddsQuota({
    observation: quotaObservation(quota),
    dailyReserve: cfg.dailyReserve,
    minuteReserve: cfg.minuteReserve,
  });
}

async function selectedLeagueIds(): Promise<{ ids: number[]; requestCount: number; quotaAfter: ApiFootballQuotaSnapshot | null; mode: string }> {
  const explicit = parseCommaSeparatedIds(process.env.FRESH_ODDS_LEAGUE_IDS);
  if (explicit.length > 0) return { ids: explicit, requestCount: 0, quotaAfter: await latestKnownQuota(), mode: 'EXPLICIT' };
  const discovery = await discoverApiFootballLeagueProfile();
  const maxLeagues = integerEnv('FRESH_ODDS_DISCOVERY_MAX_LEAGUES', discovery.selectedLeagueIds.length, 1);
  return {
    ids: discovery.selectedLeagueIds.slice(0, maxLeagues),
    requestCount: discovery.requestCount,
    quotaAfter: discovery.quotaAfter,
    mode: `PROFILE:${discovery.profile}`,
  };
}

export async function discoverFreshOddsFixtures(): Promise<unknown> {
  const cfg = config();
  const startedAt = new Date();
  const selected = await selectedLeagueIds();
  const nextPerLeague = integerEnv('FRESH_ODDS_NEXT_FIXTURES_PER_LEAGUE', 12, 1);
  let requestCount = selected.requestCount;
  let normalizedFixtures = 0;
  let insertedFixtures = 0;
  let quota = selected.quotaAfter;
  const leagueResults: Array<Record<string, unknown>> = [];

  for (const leagueId of selected.ids) {
    const guard = quotaAllowed(quota, cfg);
    if (!guard.allowed) {
      leagueResults.push({ leagueId, status: 'QUOTA_BLOCKED', reason: guard.reason });
      break;
    }
    const request = await apiFootballGet('/fixtures', {
      league: leagueId,
      next: nextPerLeague,
      timezone: apiFootballTimezone(),
    });
    requestCount += 1;
    quota = request.quota;
    const persisted = await persistFixtureRequest(request);
    normalizedFixtures += persisted.normalized;
    insertedFixtures += persisted.inserted;
    leagueResults.push({ leagueId, status: 'OK', normalized: persisted.normalized, inserted: persisted.inserted });
  }

  return {
    version: FRESH_ODDS_COLLECTOR_VERSION,
    command: 'discover',
    startedAt: startedAt.toISOString(),
    finishedAt: new Date().toISOString(),
    leagueMode: selected.mode,
    selectedLeagues: selected.ids.length,
    requestCount,
    normalizedFixtures,
    insertedFixtures,
    quotaAfter: quota,
    leagueResults,
    safety: { syntheticOddsUsed: false, realMoneyExecution: false, productionRoutingChanged: false, automaticPromotion: false },
  };
}

async function latestUpcomingFixtureSnapshots(now: Date, cfg: FreshOddsConfig): Promise<NormalizedApiFootballFixture[]> {
  const until = new Date(now.getTime() + cfg.planDaysAhead * 86_400_000);
  const rows = await prisma.apiFootballFixtureSnapshot.findMany({
    where: { kickoffAt: { gt: now, lte: until } },
    orderBy: [{ observedAt: 'desc' }, { kickoffAt: 'asc' }],
    take: Math.max(cfg.maximumTrackedFixtures * 6, cfg.maximumTrackedFixtures),
  });
  const latest = new Map<number, (typeof rows)[number]>();
  for (const row of rows) if (!latest.has(row.providerFixtureId)) latest.set(row.providerFixtureId, row);
  return [...latest.values()]
    .sort((a, b) => a.kickoffAt.getTime() - b.kickoffAt.getTime())
    .slice(0, cfg.maximumTrackedFixtures)
    .map((row) => ({
      providerFixtureId: row.providerFixtureId,
      providerLeagueId: row.providerLeagueId,
      season: row.season,
      kickoffAt: row.kickoffAt,
      statusShort: row.statusShort,
      homeProviderTeamId: row.homeProviderTeamId,
      awayProviderTeamId: row.awayProviderTeamId,
      homeTeamName: row.homeTeamName,
      awayTeamName: row.awayTeamName,
      homeGoals: row.homeGoals,
      awayGoals: row.awayGoals,
      fulltimeHomeGoals: row.fulltimeHomeGoals,
      fulltimeAwayGoals: row.fulltimeAwayGoals,
    }));
}

export async function planFreshOddsCheckpoints(now = new Date()): Promise<unknown> {
  const cfg = config();
  const fixtures = await latestUpcomingFixtureSnapshots(now, cfg);
  let created = 0;
  let refreshed = 0;
  let terminalUnchanged = 0;
  for (const fixture of fixtures) {
    for (const horizonMinutes of cfg.horizonsMinutes) {
      const dueAt = freshOddsDueAt(fixture.kickoffAt, horizonMinutes);
      const horizonLabel = freshOddsHorizonLabel(horizonMinutes);
      const existing = await prisma.apiFootballFreshOddsCheckpoint.findUnique({
        where: { providerFixtureId_horizonMinutes: { providerFixtureId: fixture.providerFixtureId, horizonMinutes } },
      });
      if (existing == null) {
        await prisma.apiFootballFreshOddsCheckpoint.create({
          data: {
            providerFixtureId: fixture.providerFixtureId,
            providerLeagueId: fixture.providerLeagueId,
            season: fixture.season,
            kickoffAt: fixture.kickoffAt,
            horizonMinutes,
            horizonLabel,
            dueAt,
            status: 'PENDING',
            metadata: jsonValue({ version: FRESH_ODDS_COLLECTOR_VERSION, closingProxy: isClosingProxyHorizon(horizonMinutes) }),
          },
        });
        created += 1;
      } else if ((TERMINAL_STATUSES as readonly string[]).includes(existing.status)) {
        terminalUnchanged += 1;
      } else {
        await prisma.apiFootballFreshOddsCheckpoint.update({
          where: { id: existing.id },
          data: {
            providerLeagueId: fixture.providerLeagueId,
            season: fixture.season,
            kickoffAt: fixture.kickoffAt,
            horizonLabel,
            dueAt,
            metadata: jsonValue({ version: FRESH_ODDS_COLLECTOR_VERSION, closingProxy: isClosingProxyHorizon(horizonMinutes), replannedAt: now.toISOString() }),
          },
        });
        refreshed += 1;
      }
    }
  }
  return {
    version: FRESH_ODDS_COLLECTOR_VERSION,
    command: 'plan',
    now: now.toISOString(),
    fixtures: fixtures.length,
    horizonsMinutes: cfg.horizonsMinutes,
    closingHorizon: 'T-5 proxy; sourceUpdatedAt age must be audited before CLV use',
    created,
    refreshed,
    terminalUnchanged,
    externalApiCalled: false,
  };
}

async function closeMissed(now: Date, cfg: FreshOddsConfig): Promise<number> {
  const rows = await prisma.apiFootballFreshOddsCheckpoint.findMany({
    where: { completedAt: null, status: { in: ['PENDING', 'RETRY', 'FAILED', 'RUNNING'] }, dueAt: { lt: new Date(now.getTime() - cfg.toleranceMinutes * 60_000) } },
    take: 5000,
  });
  let skipped = 0;
  for (const row of rows) {
    const state = classifyFreshOddsWindow({ now, kickoffAt: row.kickoffAt, dueAt: row.dueAt, leadMinutes: cfg.leadMinutes, toleranceMinutes: cfg.toleranceMinutes });
    if (state !== 'MISSED' && state !== 'AFTER_KICKOFF') continue;
    const result = await prisma.apiFootballFreshOddsCheckpoint.updateMany({
      where: { id: row.id, completedAt: null },
      data: {
        status: 'SKIPPED', completedAt: now, nextRetryAt: null, lockToken: null,
        errorMessage: state === 'AFTER_KICKOFF' ? 'Collection blocked at or after kickoff.' : 'Fresh odds horizon window was missed.',
        metadata: jsonValue({ state, closedAt: now.toISOString(), version: FRESH_ODDS_COLLECTOR_VERSION }),
      },
    });
    skipped += result.count;
  }
  return skipped;
}

async function dueCheckpoints(now: Date, cfg: FreshOddsConfig): Promise<DueCheckpoint[]> {
  const stale = new Date(now.getTime() - cfg.lockMinutes * 60_000);
  return prisma.apiFootballFreshOddsCheckpoint.findMany({
    where: {
      completedAt: null,
      kickoffAt: { gt: now },
      dueAt: { gte: new Date(now.getTime() - cfg.toleranceMinutes * 60_000), lte: new Date(now.getTime() + cfg.leadMinutes * 60_000) },
      OR: [
        { status: 'PENDING' },
        { status: { in: ['RETRY', 'FAILED'] }, OR: [{ nextRetryAt: null }, { nextRetryAt: { lte: now } }] },
        { status: 'RUNNING', updatedAt: { lte: stale } },
      ],
    },
    orderBy: [{ dueAt: 'asc' }, { horizonMinutes: 'desc' }, { id: 'asc' }],
    take: cfg.maximumDuePerTick,
  });
}

async function claim(row: DueCheckpoint, now: Date): Promise<string | null> {
  const token = randomUUID();
  const result = await prisma.apiFootballFreshOddsCheckpoint.updateMany({
    where: { id: row.id, status: row.status, updatedAt: row.updatedAt, completedAt: null },
    data: { status: 'RUNNING', lockToken: token, attemptedAt: now, attempts: { increment: 1 }, errorMessage: null },
  });
  return result.count === 1 ? token : null;
}

async function finish(input: {
  row: DueCheckpoint;
  token: string;
  now: Date;
  cfg: FreshOddsConfig;
  requestCount: number;
  normalizedOdds: number;
  insertedOdds: number;
  pitUsableOdds: number;
  quota: ApiFootballQuotaSnapshot | null;
  sourceAgeSummary?: ReturnType<typeof summarizeSourceAges>;
  errorMessage?: string;
}): Promise<CheckpointStatus> {
  const attempts = input.row.attempts + 1;
  const windowClosed = input.now.getTime() >= input.row.dueAt.getTime() + input.cfg.toleranceMinutes * 60_000;
  const exhausted = attempts >= input.cfg.maximumAttempts;
  let status: CheckpointStatus;
  let completedAt: Date | null;
  let nextRetryAt: Date | null;
  let errorMessage: string | null;
  if (input.normalizedOdds > 0) {
    status = 'SUCCESS'; completedAt = input.now; nextRetryAt = null; errorMessage = null;
  } else if (windowClosed || exhausted) {
    status = input.errorMessage ? 'FAILED' : 'EMPTY'; completedAt = input.now; nextRetryAt = null; errorMessage = input.errorMessage ?? 'API returned no normalized scientific pre-match odds.';
  } else {
    status = 'RETRY'; completedAt = null; nextRetryAt = new Date(input.now.getTime() + input.cfg.retryMinutes * 60_000); errorMessage = input.errorMessage ?? 'No usable odds yet; retry scheduled.';
  }
  await prisma.apiFootballFreshOddsCheckpoint.updateMany({
    where: { id: input.row.id, lockToken: input.token },
    data: {
      status,
      completedAt,
      nextRetryAt,
      lockToken: null,
      requestCount: input.requestCount,
      normalizedOdds: input.normalizedOdds,
      insertedOdds: input.insertedOdds,
      pitUsableOdds: input.pitUsableOdds,
      quotaRemainingDay: input.quota?.requestsRemainingDay ?? null,
      quotaRemainingMinute: input.quota?.rateRemainingPerMinute ?? null,
      errorMessage,
      metadata: jsonValue({
        version: FRESH_ODDS_COLLECTOR_VERSION,
        horizonMinutes: input.row.horizonMinutes,
        horizonLabel: input.row.horizonLabel,
        closingProxy: isClosingProxyHorizon(input.row.horizonMinutes),
        dueAt: input.row.dueAt.toISOString(),
        observedAt: input.now.toISOString(),
        sourceAgeSummary: input.sourceAgeSummary ?? null,
        scientificNote: isClosingProxyHorizon(input.row.horizonMinutes)
          ? 'T-5 is a closing proxy. Because API-Football pre-match odds refresh roughly every 3 hours, CLV must audit sourceUpdatedAt age before treating this as closing evidence.'
          : null,
      }),
    },
  });
  return status;
}

export async function collectFreshOddsDue(now = new Date()): Promise<unknown> {
  const cfg = config();
  const skipped = await closeMissed(now, cfg);
  const due = await dueCheckpoints(now, cfg);
  let quota = await latestKnownQuota();
  let quotaBlocked: string | null = null;
  let claimed = 0;
  let requests = 0;
  let normalizedOdds = 0;
  let insertedOdds = 0;
  let pitUsableOdds = 0;
  const statuses: Record<string, number> = {};

  for (const row of due) {
    const guard = quotaAllowed(quota, cfg);
    if (!guard.allowed) { quotaBlocked = guard.reason; break; }
    if (new Date().getTime() >= row.kickoffAt.getTime()) continue;
    const token = await claim(row, new Date());
    if (token == null) continue;
    claimed += 1;
    try {
      const request = await apiFootballGet('/odds', { fixture: row.providerFixtureId, timezone: apiFootballTimezone() });
      requests += 1;
      quota = request.quota;
      await persistRawOddsRequest({ request, checkpoint: row });
      const persisted = await persistOdds({ request, checkpoint: row });
      normalizedOdds += persisted.normalized;
      insertedOdds += persisted.inserted;
      pitUsableOdds += persisted.pitUsable;
      const status = await finish({
        row, token, now: request.observedAt, cfg, requestCount: 1,
        normalizedOdds: persisted.normalized, insertedOdds: persisted.inserted, pitUsableOdds: persisted.pitUsable,
        quota, sourceAgeSummary: persisted.sourceAgeSummary,
      });
      statuses[status] = (statuses[status] ?? 0) + 1;
    } catch (error) {
      const status = await finish({
        row, token, now: new Date(), cfg, requestCount: 0, normalizedOdds: 0, insertedOdds: 0, pitUsableOdds: 0, quota,
        errorMessage: error instanceof Error ? error.message : String(error),
      });
      statuses[status] = (statuses[status] ?? 0) + 1;
    }
  }

  return {
    version: FRESH_ODDS_COLLECTOR_VERSION,
    command: 'tick',
    now: now.toISOString(),
    due: due.length,
    skipped,
    claimed,
    requests,
    normalizedOdds,
    insertedOdds,
    pitUsableOdds,
    statuses,
    quotaBlocked,
    quotaAfter: quota,
    safety: { syntheticOddsUsed: false, realMoneyExecution: false, productionRoutingChanged: false, automaticPromotion: false },
  };
}

export async function freshOddsReadiness(now = new Date()): Promise<unknown> {
  const cfg = config();
  const fixtures = await latestUpcomingFixtureSnapshots(now, cfg);
  const [checkpoints, oddsRows, pitRows] = await Promise.all([
    prisma.apiFootballFreshOddsCheckpoint.count(),
    prisma.apiFootballOddsSnapshot.count(),
    prisma.apiFootballOddsSnapshot.count({ where: { pitUsable: true } }),
  ]);
  return {
    version: FRESH_ODDS_COLLECTOR_VERSION,
    command: 'readiness',
    externalApiCalled: false,
    apiKeyConfigured: Boolean(process.env.API_FOOTBALL_KEY ?? process.env.API_FOOTBALL_API_KEY ?? process.env.APISPORTS_KEY ?? process.env.API_SPORTS_KEY),
    upcomingProviderFixtures: fixtures.length,
    upcomingLeagues: [...new Set(fixtures.map((fixture) => fixture.providerLeagueId))].length,
    horizonsMinutes: cfg.horizonsMinutes,
    horizonLabels: cfg.horizonsMinutes.map(freshOddsHorizonLabel),
    checkpointRows: checkpoints,
    existingApiFootballOddsRows: oddsRows,
    existingPitUsableOddsRows: pitRows,
    quotaPolicy: { dailyReserve: cfg.dailyReserve, minuteReserve: cfg.minuteReserve },
    closingPolicy: 'T-5 closing proxy; audit sourceUpdatedAt freshness before CLV.',
  };
}

export async function getFreshOddsCoverage(): Promise<unknown> {
  const [checkpoints, oddsRows, pitRows, latestOdds] = await Promise.all([
    prisma.apiFootballFreshOddsCheckpoint.findMany({ orderBy: [{ horizonMinutes: 'desc' }, { dueAt: 'asc' }] }),
    prisma.apiFootballOddsSnapshot.count(),
    prisma.apiFootballOddsSnapshot.count({ where: { pitUsable: true } }),
    prisma.apiFootballOddsSnapshot.findFirst({ orderBy: { observedAt: 'desc' }, select: { observedAt: true, sourceUpdatedAt: true, providerFixtureId: true } }),
  ]);
  const grouped = new Map<number, Record<string, number | string>>();
  for (const row of checkpoints) {
    const current = grouped.get(row.horizonMinutes) ?? {
      horizonMinutes: row.horizonMinutes,
      label: row.horizonLabel,
      total: 0, success: 0, empty: 0, retry: 0, failed: 0, skipped: 0, pending: 0,
      normalizedOdds: 0, insertedOdds: 0, pitUsableOdds: 0,
    };
    current.total = Number(current.total) + 1;
    current.normalizedOdds = Number(current.normalizedOdds) + row.normalizedOdds;
    current.insertedOdds = Number(current.insertedOdds) + row.insertedOdds;
    current.pitUsableOdds = Number(current.pitUsableOdds) + row.pitUsableOdds;
    const key = row.status === 'SUCCESS' ? 'success' : row.status === 'EMPTY' ? 'empty' : row.status === 'RETRY' ? 'retry' : row.status === 'FAILED' ? 'failed' : row.status === 'SKIPPED' ? 'skipped' : 'pending';
    current[key] = Number(current[key]) + 1;
    grouped.set(row.horizonMinutes, current);
  }
  return {
    version: FRESH_ODDS_COLLECTOR_VERSION,
    command: 'coverage',
    totalCheckpoints: checkpoints.length,
    completedCheckpoints: checkpoints.filter((row: { status: string }) => (TERMINAL_STATUSES as readonly string[]).includes(row.status)).length,
    pendingCheckpoints: checkpoints.filter((row: { status: string }) => !(TERMINAL_STATUSES as readonly string[]).includes(row.status)).length,
    byHorizon: [...grouped.values()].sort((a, b) => Number(b.horizonMinutes) - Number(a.horizonMinutes)),
    apiFootballOddsRows: oddsRows,
    pitUsableOddsRows: pitRows,
    latestOdds: latestOdds == null ? null : {
      providerFixtureId: latestOdds.providerFixtureId,
      observedAt: latestOdds.observedAt.toISOString(),
      sourceUpdatedAt: latestOdds.sourceUpdatedAt?.toISOString() ?? null,
      sourceAgeMinutes: sourceAgeMinutes({ observedAt: latestOdds.observedAt, sourceUpdatedAt: latestOdds.sourceUpdatedAt }),
    },
    integrity: { syntheticOddsUsed: false, realMoneyExecution: false, productionRoutingChanged: false, automaticPromotion: false },
  };
}

export async function runFreshOddsOnce(): Promise<unknown> {
  const discover = booleanEnv('FRESH_ODDS_ONCE_DISCOVER', true) ? await discoverFreshOddsFixtures() : null;
  const plan = await planFreshOddsCheckpoints();
  const tick = await collectFreshOddsDue();
  return { version: FRESH_ODDS_COLLECTOR_VERSION, command: 'once', discover, plan, tick };
}
