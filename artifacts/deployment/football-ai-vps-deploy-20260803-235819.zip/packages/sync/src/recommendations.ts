import { generateScientificRecommendations } from './scientific-recommendations.js';
import {
  clamp,
  expectedValue,
  impliedProbability,
  median,
  normalizeProbabilities,
  removeVig,
  standardDeviation,
  type LatestOdds,
  type ModelProbabilitySet,
  type SupportedMarketCode,
} from '@football-ai/engine';
import {
  FixtureStatus,
  prisma,
  RecommendationStatus,
  type InputJsonValue,
} from '@football-ai/database';
import {
  getFixtureHoursAhead,
  getLineupAnalysisRules,
  getRecommendationRules,
} from './config.js';
import { getFixtureLineupAnalysis } from './lineup-analysis.js';
import { runTrackedSync, type SyncSummary } from './tracking.js';

type OverUnderSelection = 'OVER' | 'UNDER';
type FixtureLineupAnalysis = Awaited<ReturnType<typeof getFixtureLineupAnalysis>>;

interface OddsSnapshotRow {
  id: number;
  bookmakerId: number;
  selectionCode: string;
  selectionName: string;
  lineValue: number | null;
  decimalOdds: number;
  capturedAt: Date;
  isLive?: boolean;
  bookmaker: {
    name: string;
  };
  market: {
    marketCode: string;
    name: string;
    marketGroup: string;
  };
}

interface CompleteOverUnderMarket {
  bookmakerId: number;
  bookmakerName: string;
  over: LatestOdds;
  under: LatestOdds;
  fairOverProbability: number;
  fairUnderProbability: number;
}

interface OddsDrivenOverUnderRules {
  /** null = tự động phân tích toàn bộ line lấy được. */
  allowedLineValues: number[] | null;
  minimumCompleteBookmakers: number;
  minimumReferenceBookmakers: number;
  minimumOdds: number;
  maximumOdds: number;
  minimumExpectedValue: number;
  minimumEdge: number;
  minimumConfidence: number;
  minimumDataQuality: number;
  maximumProbabilityStddev: number;
  maximumOddsAgeMinutes: number;
  /** 0 = giữ toàn bộ candidate đạt điều kiện của từng line. */
  maximumRecommendationsPerLine: number;
  /** 0 = không giới hạn tổng candidate của một trận. */
  maximumRecommendationsPerFixture: number;
}

interface OddsDrivenOverUnderCandidate {
  oddsSnapshotId: number;
  bookmakerId: number;
  bookmakerName: string;
  marketCode: 'TOTAL_GOALS_2_5';
  marketName: string;
  marketGroup: string;
  selectionCode: OverUnderSelection;
  selectionName: string;
  lineValue: number;
  decimalOdds: number;
  consensusProbability: number;
  candidateFairProbability: number;
  impliedProbability: number;
  edge: number;
  expectedValue: number;
  confidenceScore: number;
  dataQualityScore: number;
  recommendationScore: number;
  referenceBookmakerCount: number;
  probabilityStddev: number;
  reasons: string[];
}

function numberEnvironment(name: string, fallback: number): number {
  const parsed = Number(process.env[name]);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function nonNegativeIntegerEnvironment(name: string, fallback: number): number {
  return Math.max(0, Math.floor(numberEnvironment(name, fallback)));
}

function lineValuesEnvironment(name: string): number[] | null {
  const raw = process.env[name]?.trim();
  if (!raw) return null;

  const values = raw
    .split(',')
    .map((value) => Number(value.trim()))
    .filter((value) => Number.isFinite(value) && value >= 0)
    .map((value) => Number(value.toFixed(4)));

  return values.length > 0 ? [...new Set(values)].sort((a, b) => a - b) : null;
}

function approximatelyEqual(left: number, right: number): boolean {
  return Math.abs(left - right) < 0.0001;
}

/**
 * Giữ lại để module backtest cũ vẫn biên dịch được.
 * Recommendation trực tiếp bên dưới không dùng Poisson/API prediction nữa.
 */
export function blendMatchWinner(
  poisson: ModelProbabilitySet['MATCH_WINNER'],
  external?: {
    homeProbability: number | null;
    drawProbability: number | null;
    awayProbability: number | null;
  } | null,
): {
  probabilities: ModelProbabilitySet['MATCH_WINNER'];
  agreement?: Record<'HOME' | 'DRAW' | 'AWAY', number>;
} {
  if (
    external?.homeProbability == null ||
    external.drawProbability == null ||
    external.awayProbability == null
  ) {
    return { probabilities: poisson };
  }

  const externalProbabilities = normalizeProbabilities({
    HOME: external.homeProbability,
    DRAW: external.drawProbability,
    AWAY: external.awayProbability,
  });

  return {
    probabilities: normalizeProbabilities({
      HOME: poisson.HOME * 0.75 + externalProbabilities.HOME * 0.25,
      DRAW: poisson.DRAW * 0.75 + externalProbabilities.DRAW * 0.25,
      AWAY: poisson.AWAY * 0.75 + externalProbabilities.AWAY * 0.25,
    }),
    agreement: {
      HOME: clamp(1 - Math.abs(poisson.HOME - externalProbabilities.HOME) * 2, 0, 1),
      DRAW: clamp(1 - Math.abs(poisson.DRAW - externalProbabilities.DRAW) * 2, 0, 1),
      AWAY: clamp(1 - Math.abs(poisson.AWAY - externalProbabilities.AWAY) * 2, 0, 1),
    },
  };
}

/**
 * Lấy snapshot mới nhất cho từng bookmaker / market / selection / line.
 * O/U giữ toàn bộ lineValue mà nguồn odds trả về, không còn khóa ở 2.5.
 */
export function latestOddsRows(rows: OddsSnapshotRow[]): LatestOdds[] {
  const latest = new Map<string, OddsSnapshotRow>();
  const sortedRows = [...rows].sort(
    (left, right) => right.capturedAt.getTime() - left.capturedAt.getTime(),
  );

  for (const row of sortedRows) {
    if (row.isLive) continue;
    if (!['MATCH_WINNER', 'TOTAL_GOALS_2_5', 'BTTS'].includes(row.market.marketCode)) {
      continue;
    }

    const key = [
      row.bookmakerId,
      row.market.marketCode,
      row.selectionCode,
      row.lineValue ?? '',
    ].join(':');

    if (!latest.has(key)) latest.set(key, row);
  }

  return [...latest.values()].map((row) => ({
    id: row.id,
    bookmakerId: row.bookmakerId,
    bookmakerName: row.bookmaker.name,
    marketCode: row.market.marketCode as SupportedMarketCode,
    marketName: row.market.name,
    marketGroup: row.market.marketGroup,
    selectionCode: row.selectionCode,
    selectionName: row.selectionName,
    lineValue: row.lineValue,
    decimalOdds: row.decimalOdds,
    capturedAt: row.capturedAt,
  }));
}


/**
 * Hàm tương thích cho backtest cũ.
 *
 * Backtest hiện tại đánh giá thị trường Over/Under 2.5, vì vậy mặc định chỉ
 * trả các snapshot mới nhất của line 2.5. Có thể truyền lineValue khác khi cần.
 * Việc tách riêng hàm này tránh trộn nhiều line trong kết quả backtest trong khi
 * luồng generateRecommendations vẫn phân tích toàn bộ line lấy được.
 */
export type LatestOverUnderOdds = LatestOdds & {
  marketCode: 'TOTAL_GOALS_2_5';
  selectionCode: OverUnderSelection;
  lineValue: number;
};

function isLatestOverUnderOdds(
  row: LatestOdds,
  lineValue: number,
): row is LatestOverUnderOdds {
  return (
    row.marketCode === 'TOTAL_GOALS_2_5' &&
    (row.selectionCode === 'OVER' || row.selectionCode === 'UNDER') &&
    row.lineValue != null &&
    approximatelyEqual(row.lineValue, lineValue)
  );
}

export function latestOverUnderOddsRows(
  rows: OddsSnapshotRow[],
  lineValue = 2.5,
): LatestOverUnderOdds[] {
  return latestOddsRows(rows).filter((row): row is LatestOverUnderOdds =>
    isLatestOverUnderOdds(row, lineValue),
  );
}

/** Giữ lại để module backtest Poisson cũ vẫn hoạt động. */
export function calculateDataQuality(input: {
  historySampleSize: number;
  bookmakerCount: number;
  hasExternalPrediction: boolean;
}): number {
  const historyScore = clamp(input.historySampleSize / 10, 0.2, 1);
  const bookmakerScore = clamp(input.bookmakerCount / 4, 0.25, 1);
  const externalScore = input.hasExternalPrediction ? 1 : 0.55;

  return clamp(
    historyScore * 0.5 + bookmakerScore * 0.3 + externalScore * 0.2,
    0,
    1,
  );
}

function getOddsDrivenOverUnderRules(): OddsDrivenOverUnderRules {
  const baseRules = getRecommendationRules();
  const minimumReferenceBookmakers = Math.max(
    1,
    Math.floor(numberEnvironment('OU_MIN_REFERENCE_BOOKMAKERS', 2)),
  );
  const configuredCompleteBookmakers = Math.floor(
    numberEnvironment(
      'OU_MIN_COMPLETE_BOOKMAKERS',
      Math.max(3, baseRules.minimumBookmakers),
    ),
  );

  return {
    // Không đặt OU_LINES => phân tích tất cả line lấy được.
    // Ví dụ OU_LINES=1.5,2.0,2.25,2.5,2.75,3.0,3.5 để giới hạn.
    allowedLineValues: lineValuesEnvironment('OU_LINES'),
    minimumCompleteBookmakers: Math.max(
      minimumReferenceBookmakers + 1,
      configuredCompleteBookmakers,
    ),
    minimumReferenceBookmakers,
    minimumOdds: numberEnvironment('OU_MIN_ODDS', baseRules.minimumOdds),
    maximumOdds: numberEnvironment('OU_MAX_ODDS', baseRules.maximumOdds),
    minimumExpectedValue: numberEnvironment(
      'OU_MIN_EV',
      baseRules.minimumExpectedValue,
    ),
    minimumEdge: numberEnvironment('OU_MIN_EDGE', baseRules.minimumEdge),
    minimumConfidence: numberEnvironment(
      'OU_MIN_CONFIDENCE',
      baseRules.minimumConfidence,
    ),
    minimumDataQuality: numberEnvironment(
      'OU_MIN_DATA_QUALITY',
      baseRules.minimumDataQuality,
    ),
    maximumProbabilityStddev: numberEnvironment(
      'OU_MAX_PROBABILITY_STDDEV',
      0.04,
    ),
    maximumOddsAgeMinutes: numberEnvironment(
      'OU_MAX_ODDS_AGE_MINUTES',
      baseRules.maximumOddsAgeMinutes,
    ),
    // Mặc định lấy lựa chọn tốt nhất của mỗi line.
    // Đặt 0 nếu muốn lưu mọi bookmaker/selection vượt bộ lọc.
    maximumRecommendationsPerLine: nonNegativeIntegerEnvironment(
      'OU_MAX_RECOMMENDATIONS_PER_LINE',
      1,
    ),
    // Mặc định không giới hạn số line của một trận.
    maximumRecommendationsPerFixture: nonNegativeIntegerEnvironment(
      'OU_MAX_RECOMMENDATIONS_PER_FIXTURE',
      0,
    ),
  };
}

function getOverUnderLineValues(
  odds: LatestOdds[],
  allowedLineValues: number[] | null,
): number[] {
  const lineValues = new Set<number>();

  for (const row of odds) {
    if (
      row.marketCode !== 'TOTAL_GOALS_2_5' ||
      (row.selectionCode !== 'OVER' && row.selectionCode !== 'UNDER') ||
      row.lineValue == null ||
      !Number.isFinite(row.lineValue)
    ) {
      continue;
    }

    if (
      allowedLineValues &&
      !allowedLineValues.some((lineValue) =>
        approximatelyEqual(lineValue, row.lineValue as number),
      )
    ) {
      continue;
    }

    lineValues.add(Number(row.lineValue.toFixed(4)));
  }

  return [...lineValues].sort((left, right) => left - right);
}

function buildCompleteOverUnderMarkets(
  odds: LatestOdds[],
  lineValue: number,
): CompleteOverUnderMarket[] {
  const overUnderOdds = odds.filter(
    (row) =>
      row.marketCode === 'TOTAL_GOALS_2_5' &&
      (row.selectionCode === 'OVER' || row.selectionCode === 'UNDER') &&
      row.lineValue != null &&
      approximatelyEqual(row.lineValue, lineValue) &&
      Number.isFinite(row.decimalOdds) &&
      row.decimalOdds > 1,
  );

  const byBookmaker = new Map<number, LatestOdds[]>();

  for (const row of overUnderOdds) {
    byBookmaker.set(row.bookmakerId, [
      ...(byBookmaker.get(row.bookmakerId) ?? []),
      row,
    ]);
  }

  const completeMarkets: CompleteOverUnderMarket[] = [];

  for (const bookmakerOdds of byBookmaker.values()) {
    const over = bookmakerOdds.find((row) => row.selectionCode === 'OVER');
    const under = bookmakerOdds.find((row) => row.selectionCode === 'UNDER');
    if (!over || !under) continue;

    const fairSelections = removeVig([
      { code: 'OVER', odds: over.decimalOdds },
      { code: 'UNDER', odds: under.decimalOdds },
    ]);
    const fairOver = fairSelections.find((selection) => selection.code === 'OVER');
    const fairUnder = fairSelections.find((selection) => selection.code === 'UNDER');
    if (!fairOver || !fairUnder) continue;

    completeMarkets.push({
      bookmakerId: over.bookmakerId,
      bookmakerName: over.bookmakerName,
      over,
      under,
      fairOverProbability: fairOver.fairProbability,
      fairUnderProbability: fairUnder.fairProbability,
    });
  }

  return completeMarkets;
}

function pairAgeMinutes(pair: CompleteOverUnderMarket, now: Date): number {
  const oldestSelectionTime = Math.min(
    pair.over.capturedAt.getTime(),
    pair.under.capturedAt.getTime(),
  );

  return Math.max(0, (now.getTime() - oldestSelectionTime) / 60_000);
}

function calculateOddsConfidence(input: {
  referenceBookmakerCount: number;
  probabilityStddev: number;
  oddsAgeMinutes: number;
  maximumProbabilityStddev: number;
  maximumOddsAgeMinutes: number;
}): number {
  const bookmakerScore = clamp(input.referenceBookmakerCount / 5, 0, 1);
  const stabilityScore = clamp(
    1 -
      input.probabilityStddev /
        Math.max(input.maximumProbabilityStddev, 0.0001),
    0,
    1,
  );
  const freshnessScore = clamp(
    1 - input.oddsAgeMinutes / Math.max(input.maximumOddsAgeMinutes, 1),
    0,
    1,
  );

  return clamp(
    bookmakerScore * 0.4 + stabilityScore * 0.4 + freshnessScore * 0.2,
    0,
    1,
  );
}

function calculateOddsDataQuality(input: {
  completeBookmakerCount: number;
  referenceBookmakerCount: number;
  probabilityStddev: number;
  oddsAgeMinutes: number;
  maximumProbabilityStddev: number;
  maximumOddsAgeMinutes: number;
}): number {
  const completeMarketScore = clamp(input.completeBookmakerCount / 5, 0, 1);
  const referenceScore = clamp(input.referenceBookmakerCount / 4, 0, 1);
  const stabilityScore = clamp(
    1 -
      input.probabilityStddev /
        Math.max(input.maximumProbabilityStddev, 0.0001),
    0,
    1,
  );
  const freshnessScore = clamp(
    1 - input.oddsAgeMinutes / Math.max(input.maximumOddsAgeMinutes, 1),
    0,
    1,
  );

  return clamp(
    completeMarketScore * 0.35 +
      referenceScore * 0.25 +
      stabilityScore * 0.25 +
      freshnessScore * 0.15,
    0,
    1,
  );
}

function buildCandidatesForLine(input: {
  odds: LatestOdds[];
  rules: OddsDrivenOverUnderRules;
  now: Date;
  lineValue: number;
  lineupAnalysis?: FixtureLineupAnalysis;
}): OddsDrivenOverUnderCandidate[] {
  if (input.lineupAnalysis?.blockRecommendation) return [];
  const completeMarkets = buildCompleteOverUnderMarkets(
    input.odds,
    input.lineValue,
  );
  const freshMarkets = completeMarkets.filter(
    (market) =>
      pairAgeMinutes(market, input.now) <= input.rules.maximumOddsAgeMinutes,
  );

  if (freshMarkets.length < input.rules.minimumCompleteBookmakers) return [];

  const candidates: OddsDrivenOverUnderCandidate[] = [];

  for (const candidateMarket of freshMarkets) {
    const referenceMarkets = freshMarkets.filter(
      (market) => market.bookmakerId !== candidateMarket.bookmakerId,
    );

    if (referenceMarkets.length < input.rules.minimumReferenceBookmakers) {
      continue;
    }

    for (const selectionCode of ['OVER', 'UNDER'] as const) {
      const candidateQuote =
        selectionCode === 'OVER' ? candidateMarket.over : candidateMarket.under;
      const candidateFairProbability =
        selectionCode === 'OVER'
          ? candidateMarket.fairOverProbability
          : candidateMarket.fairUnderProbability;
      const referenceProbabilities = referenceMarkets.map((market) =>
        selectionCode === 'OVER'
          ? market.fairOverProbability
          : market.fairUnderProbability,
      );
      const marketConsensusProbability = median(referenceProbabilities);
      const lineupAdjustment = input.lineupAnalysis?.overProbabilityAdjustment ?? 0;
      const consensusProbability = clamp(
        marketConsensusProbability +
          (selectionCode === 'OVER' ? lineupAdjustment : -lineupAdjustment),
        0.01,
        0.99,
      );
      const probabilityStddev = standardDeviation(referenceProbabilities);
      const oddsAgeMinutes = pairAgeMinutes(candidateMarket, input.now);
      const selectionEdge = consensusProbability - candidateFairProbability;
      const selectionExpectedValue = expectedValue(
        consensusProbability,
        candidateQuote.decimalOdds,
      );
      const baseConfidenceScore = calculateOddsConfidence({
        referenceBookmakerCount: referenceMarkets.length,
        probabilityStddev,
        oddsAgeMinutes,
        maximumProbabilityStddev: input.rules.maximumProbabilityStddev,
        maximumOddsAgeMinutes: input.rules.maximumOddsAgeMinutes,
      });
      const confidenceScore = clamp(
        baseConfidenceScore * (input.lineupAnalysis?.confidenceMultiplier ?? 1),
        0,
        1,
      );
      const baseDataQualityScore = calculateOddsDataQuality({
        completeBookmakerCount: freshMarkets.length,
        referenceBookmakerCount: referenceMarkets.length,
        probabilityStddev,
        oddsAgeMinutes,
        maximumProbabilityStddev: input.rules.maximumProbabilityStddev,
        maximumOddsAgeMinutes: input.rules.maximumOddsAgeMinutes,
      });
      const dataQualityScore = clamp(
        baseDataQualityScore * (input.lineupAnalysis?.dataQualityMultiplier ?? 1),
        0,
        1,
      );
      const recommendationScore =
        Math.max(0, selectionExpectedValue) * confidenceScore * dataQualityScore;

      if (
        candidateQuote.decimalOdds < input.rules.minimumOdds ||
        candidateQuote.decimalOdds > input.rules.maximumOdds ||
        selectionExpectedValue < input.rules.minimumExpectedValue ||
        selectionEdge < input.rules.minimumEdge ||
        confidenceScore < input.rules.minimumConfidence ||
        dataQualityScore < input.rules.minimumDataQuality ||
        probabilityStddev > input.rules.maximumProbabilityStddev ||
        oddsAgeMinutes > input.rules.maximumOddsAgeMinutes
      ) {
        continue;
      }

      candidates.push({
        oddsSnapshotId: candidateQuote.id,
        bookmakerId: candidateQuote.bookmakerId,
        bookmakerName: candidateQuote.bookmakerName,
        // Giữ market code cũ để không phải migration database.
        // lineValue mới là trường phân biệt 1.5, 2.0, 2.25, 2.5, 3.5...
        marketCode: 'TOTAL_GOALS_2_5',
        marketName: candidateQuote.marketName,
        marketGroup: candidateQuote.marketGroup,
        selectionCode,
        selectionName: `${selectionCode === 'OVER' ? 'Over' : 'Under'} ${input.lineValue}`,
        lineValue: input.lineValue,
        decimalOdds: candidateQuote.decimalOdds,
        consensusProbability,
        candidateFairProbability,
        impliedProbability: impliedProbability(candidateQuote.decimalOdds),
        edge: selectionEdge,
        expectedValue: selectionExpectedValue,
        confidenceScore,
        dataQualityScore,
        recommendationScore,
        referenceBookmakerCount: referenceMarkets.length,
        probabilityStddev,
        reasons: [
          `Line Tài/Xỉu ${input.lineValue}.`,
          `Consensus ${selectionCode === 'OVER' ? 'Over' : 'Under'} ${input.lineValue}: ${(consensusProbability * 100).toFixed(1)}%.`,
          `Đã loại ${candidateQuote.bookmakerName} khỏi consensus; còn ${referenceMarkets.length} nhà cái tham chiếu.`,
          `EV ${(selectionExpectedValue * 100).toFixed(1)}%, edge ${(selectionEdge * 100).toFixed(1)} điểm %.`,
          `Odds ${candidateQuote.decimalOdds.toFixed(2)} tại ${candidateQuote.bookmakerName}.`,
          `Độ lệch xác suất ${(probabilityStddev * 100).toFixed(2)}%, confidence ${(confidenceScore * 100).toFixed(0)}%.`,
          ...(input.lineupAnalysis?.available
            ? [
                `Điều chỉnh đội hình cho Over: ${(
                  input.lineupAnalysis.overProbabilityAdjustment * 100
                ).toFixed(1)} điểm %.`,
                ...input.lineupAnalysis.reasons,
              ]
            : []),
        ],
      });
    }
  }

  candidates.sort(
    (left, right) => right.recommendationScore - left.recommendationScore,
  );

  return candidates;
}

/**
 * Phân tích toàn bộ line Tài/Xỉu lấy được:
 *
 * 1. Tự phát hiện mọi lineValue đang có trong odds snapshot.
 * 2. Phân tích từng line độc lập; không trộn xác suất giữa 2.5 và 3.5.
 * 3. Với từng bookmaker, chỉ dùng cặp có đủ Over và Under cùng line.
 * 4. Loại bookmaker đang đánh giá khỏi tập consensus.
 * 5. Loại vig, lấy median probability, tính edge/EV/confidence/data quality.
 * 6. Mặc định giữ candidate tốt nhất của mỗi line; cấu hình 0 để giữ toàn bộ.
 */
export function buildOddsDrivenOverUnderCandidates(input: {
  odds: LatestOdds[];
  rules: OddsDrivenOverUnderRules;
  now: Date;
  lineupAnalysis?: FixtureLineupAnalysis;
}): OddsDrivenOverUnderCandidate[] {
  if (input.lineupAnalysis?.blockRecommendation) return [];
  const lineValues = getOverUnderLineValues(
    input.odds,
    input.rules.allowedLineValues,
  );
  const candidates: OddsDrivenOverUnderCandidate[] = [];

  for (const lineValue of lineValues) {
    const lineCandidates = buildCandidatesForLine({
      odds: input.odds,
      rules: input.rules,
      now: input.now,
      lineValue,
      lineupAnalysis: input.lineupAnalysis,
    });

    if (input.rules.maximumRecommendationsPerLine === 0) {
      candidates.push(...lineCandidates);
    } else {
      candidates.push(
        ...lineCandidates.slice(0, input.rules.maximumRecommendationsPerLine),
      );
    }
  }

  candidates.sort(
    (left, right) => right.recommendationScore - left.recommendationScore,
  );

  if (input.rules.maximumRecommendationsPerFixture === 0) {
    return candidates;
  }

  return candidates.slice(0, input.rules.maximumRecommendationsPerFixture);
}

export async function generateRecommendations() {
  return generateScientificRecommendations();
}