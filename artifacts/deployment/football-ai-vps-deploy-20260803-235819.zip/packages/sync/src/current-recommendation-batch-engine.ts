import { prisma } from '@football-ai/database';

import {
  buildNoProviderFixtureSnapshotAnalysis,
  getCurrentScientificRecommendationMap,
  type CurrentScientificRecommendationAnalysis,
} from './current-scientific-recommendation-engine.js';
import {
  REOBSERVATION_RAW_KINDS,
} from './fresh-odds-reobservation-bridge.js';
import {
  CURRENT_RECOMMENDATION_BATCH_VERSION,
  chunkCurrentRecommendationFixtures,
  findUnclassifiedSelectedFixtureIds,
  prioritizeCurrentRecommendationFixtures,
  type CurrentRecommendationBatchFixture,
  type PrioritizedCurrentRecommendationFixture,
} from './current-recommendation-batch-core.js';

interface RecentRawAttemptRow {
  providerFixtureId: number | null;
}

interface PitOddsFixtureRow {
  providerFixtureId: number;
}

export interface CurrentRecommendationBatchDiagnostics {
  version: string;
  requestedFixtures: number;
  selectedFixtures: number;
  evaluatedFixtures: number;
  notEvaluatedFixtures: number;
  maximumFixtures: number;
  chunkSize: number;
  chunksPlanned: number;
  chunksCompleted: number;
  failedChunks: number;
  singleFixtureRetries: number;
  singleFixtureRetrySuccesses: number;
  missingProviderSnapshotClassifications: number;
  recentRawAttemptFixtures: number;
  pitOddsFixtures: number;
  checkpointPriorityFixtures: number;
  kickoffWithin6hFixtures: number;
  signalQueryError: string | null;
  errors: Array<{
    scope: 'SIGNALS' | 'CHUNK' | 'SINGLE';
    providerFixtureIds: number[];
    reason: string;
  }>;
  strategy:
    'CHECKPOINT_RAW_ODDS_KICKOFF_CHUNKED_FAULT_ISOLATION';
  externalApiCalled: false;
  databaseWritten: false;
  realMoneyExecution: false;
}

export interface CurrentRecommendationBatchResult {
  analyses: Map<
    number,
    CurrentScientificRecommendationAnalysis
  >;
  prioritizedFixtures:
    PrioritizedCurrentRecommendationFixture[];
  diagnostics:
    CurrentRecommendationBatchDiagnostics;
}

export function emptyCurrentRecommendationBatchDiagnostics(
  requestedFixtures: number,
  reason: string | null = null,
): CurrentRecommendationBatchDiagnostics {
  return {
    version:
      CURRENT_RECOMMENDATION_BATCH_VERSION,
    requestedFixtures,
    selectedFixtures: 0,
    evaluatedFixtures: 0,
    notEvaluatedFixtures:
      requestedFixtures,
    maximumFixtures: 0,
    chunkSize: 0,
    chunksPlanned: 0,
    chunksCompleted: 0,
    failedChunks: 0,
    singleFixtureRetries: 0,
    singleFixtureRetrySuccesses: 0,
    missingProviderSnapshotClassifications: 0,
    recentRawAttemptFixtures: 0,
    pitOddsFixtures: 0,
    checkpointPriorityFixtures: 0,
    kickoffWithin6hFixtures: 0,
    signalQueryError:
      reason,
    errors:
      reason == null
        ? []
        : [
            {
              scope:
                'CHUNK',
              providerFixtureIds:
                [],
              reason,
            },
          ],
    strategy:
      'CHECKPOINT_RAW_ODDS_KICKOFF_CHUNKED_FAULT_ISOLATION',
    externalApiCalled:
      false,
    databaseWritten:
      false,
    realMoneyExecution:
      false,
  };
}

function envInteger(
  name: string,
  fallback: number,
  minimum: number,
  maximum: number,
): number {
  const raw =
    process.env[name];

  if (
    raw == null ||
    raw.trim() === ''
  ) {
    return fallback;
  }

  const value =
    Number(raw);

  if (
    !Number.isSafeInteger(
      value,
    ) ||
    value < minimum ||
    value > maximum
  ) {
    throw new Error(
      `${name} must be an integer from ${minimum} to ${maximum}.`,
    );
  }

  return value;
}

function errorMessage(
  error: unknown,
): string {
  return error instanceof Error
    ? error.message
    : String(error);
}

async function loadPrioritySignals(input: {
  providerFixtureIds: number[];
  now: Date;
  freshnessMinutes: number;
}): Promise<{
  recentRawAttemptFixtureIds:
    Set<number>;
  pitOddsFixtureIds:
    Set<number>;
  error: string | null;
}> {
  if (
    input.providerFixtureIds.length ===
    0
  ) {
    return {
      recentRawAttemptFixtureIds:
        new Set<number>(),
      pitOddsFixtureIds:
        new Set<number>(),
      error: null,
    };
  }

  const freshnessCutoff =
    new Date(
      input.now.getTime() -
        input.freshnessMinutes *
          60_000,
    );

  const oddsLookbackCutoff =
    new Date(
      input.now.getTime() -
        14 *
          86_400_000,
    );

  try {
    const [
      rawRows,
      oddsRows,
    ] = await Promise.all([
      prisma.apiFootballDataSnapshot.findMany({
        where: {
          kind: {
            in: [
              ...REOBSERVATION_RAW_KINDS,
            ],
          },
          providerFixtureId: {
            in:
              input.providerFixtureIds,
          },
          observedAt: {
            gte:
              freshnessCutoff,
            lte:
              input.now,
          },
        },
        select: {
          providerFixtureId: true,
        },
        orderBy: [
          {
            observedAt: 'desc',
          },
          {
            id: 'desc',
          },
        ],
        take: Math.max(
          500,
          input
            .providerFixtureIds
            .length *
            20,
        ),
      }) as Promise<
        RecentRawAttemptRow[]
      >,
      prisma.apiFootballOddsSnapshot.findMany({
        where: {
          providerFixtureId: {
            in:
              input.providerFixtureIds,
          },
          pitUsable: true,
          observedAt: {
            gte:
              oddsLookbackCutoff,
            lte:
              input.now,
          },
          kickoffAt: {
            gt:
              input.now,
          },
        },
        select: {
          providerFixtureId: true,
        },
        distinct: [
          'providerFixtureId',
        ],
        take:
          input
            .providerFixtureIds
            .length,
      }) as Promise<
        PitOddsFixtureRow[]
      >,
    ]);

    return {
      recentRawAttemptFixtureIds:
        new Set(
          rawRows
            .map(
              (
                row:
                  RecentRawAttemptRow,
              ): number | null =>
                row.providerFixtureId,
            )
            .filter(
              (
                value:
                  number | null,
              ): value is number =>
                value != null,
            ),
        ),
      pitOddsFixtureIds:
        new Set(
          oddsRows.map(
            (
              row:
                PitOddsFixtureRow,
            ): number =>
              row.providerFixtureId,
          ),
        ),
      error: null,
    };
  } catch (error) {
    return {
      recentRawAttemptFixtureIds:
        new Set<number>(),
      pitOddsFixtureIds:
        new Set<number>(),
      error:
        errorMessage(error),
    };
  }
}

export async function getPrioritizedCurrentRecommendationBatch(
  input: {
    fixtures:
      CurrentRecommendationBatchFixture[];
    now?: Date;
    maximumFixtures?: number;
    chunkSize?: number;
    freshnessMinutes?: number;
  },
): Promise<CurrentRecommendationBatchResult> {
  const now =
    input.now ??
    new Date();

  const maximumFixtures =
    input.maximumFixtures ??
    envInteger(
      'CURRENT_RECOMMENDATION_BATCH_MAX_FIXTURES',
      180,
      1,
      300,
    );

  const chunkSize =
    input.chunkSize ??
    envInteger(
      'CURRENT_RECOMMENDATION_BATCH_CHUNK_SIZE',
      20,
      1,
      50,
    );

  const freshnessMinutes =
    input.freshnessMinutes ??
    envInteger(
      'CURRENT_RECOMMENDATION_MAX_ODDS_AGE_MINUTES',
      360,
      1,
      1440,
    );

  const uniqueFixtures =
    [
      ...new Map(
        input.fixtures.map(
          (
            fixture:
              CurrentRecommendationBatchFixture,
          ): [
            number,
            CurrentRecommendationBatchFixture,
          ] => [
            fixture.providerFixtureId,
            fixture,
          ],
        ),
      ).values(),
    ];

  const providerFixtureIds =
    uniqueFixtures.map(
      (
        fixture:
          CurrentRecommendationBatchFixture,
      ): number =>
        fixture.providerFixtureId,
    );

  const signals =
    await loadPrioritySignals({
      providerFixtureIds,
      now,
      freshnessMinutes,
    });

  const prioritizedFixtures =
    prioritizeCurrentRecommendationFixtures({
      fixtures:
        uniqueFixtures,
      now,
      signals: {
        recentRawAttemptFixtureIds:
          signals
            .recentRawAttemptFixtureIds,
        pitOddsFixtureIds:
          signals
            .pitOddsFixtureIds,
      },
    });

  const selectedFixtures =
    prioritizedFixtures.slice(
      0,
      maximumFixtures,
    );

  const chunks =
    chunkCurrentRecommendationFixtures(
      selectedFixtures,
      chunkSize,
    );

  const analyses =
    new Map<
      number,
      CurrentScientificRecommendationAnalysis
    >();

  const errors:
    CurrentRecommendationBatchDiagnostics[
      'errors'
    ] = [];

  if (signals.error != null) {
    errors.push({
      scope:
        'SIGNALS',
      providerFixtureIds: [],
      reason:
        signals.error,
    });
  }

  let chunksCompleted = 0;
  let failedChunks = 0;
  let singleFixtureRetries = 0;
  let singleFixtureRetrySuccesses = 0;

  for (const chunk of chunks) {
    const chunkIds =
      chunk.map(
        (
          fixture:
            PrioritizedCurrentRecommendationFixture,
        ): number =>
          fixture.providerFixtureId,
      );

    let chunkMap:
      Map<
        number,
        CurrentScientificRecommendationAnalysis
      > | null = null;

    try {
      chunkMap =
        await getCurrentScientificRecommendationMap({
          providerFixtureIds:
            chunkIds,
          now,
          maxFixtures:
            chunkIds.length,
        });

      chunksCompleted += 1;

      for (
        const [
          providerFixtureId,
          analysis,
        ] of chunkMap
      ) {
        analyses.set(
          providerFixtureId,
          analysis,
        );
      }
    } catch (error) {
      failedChunks += 1;

      errors.push({
        scope:
          'CHUNK',
        providerFixtureIds:
          chunkIds,
        reason:
          errorMessage(error),
      });
    }

    const missingIds =
      chunkIds.filter(
        (
          providerFixtureId:
            number,
        ): boolean =>
          !analyses.has(
            providerFixtureId,
          ),
      );

    for (
      const providerFixtureId of
      missingIds
    ) {
      singleFixtureRetries += 1;

      try {
        const singleMap =
          await getCurrentScientificRecommendationMap({
            providerFixtureIds: [
              providerFixtureId,
            ],
            now,
            maxFixtures: 1,
          });

        const analysis =
          singleMap.get(
            providerFixtureId,
          );

        if (analysis != null) {
          analyses.set(
            providerFixtureId,
            analysis,
          );

          singleFixtureRetrySuccesses += 1;
        }
      } catch (error) {
        errors.push({
          scope:
            'SINGLE',
          providerFixtureIds: [
            providerFixtureId,
          ],
          reason:
            errorMessage(error),
        });
      }
    }
  }

  const selectedByProviderFixtureId =
    new Map(
      selectedFixtures.map(
        (
          fixture:
            PrioritizedCurrentRecommendationFixture,
        ): [
          number,
          PrioritizedCurrentRecommendationFixture,
        ] => [
          fixture.providerFixtureId,
          fixture,
        ],
      ),
    );

  const unclassifiedSelectedFixtureIds =
    findUnclassifiedSelectedFixtureIds(
      selectedFixtures.map(
        (
          fixture:
            PrioritizedCurrentRecommendationFixture,
        ): number =>
          fixture.providerFixtureId,
      ),
      analyses.keys(),
    );

  for (
    const providerFixtureId of
    unclassifiedSelectedFixtureIds
  ) {
    const fixture =
      selectedByProviderFixtureId.get(
        providerFixtureId,
      );

    if (fixture == null) {
      continue;
    }

    analyses.set(
      providerFixtureId,
      buildNoProviderFixtureSnapshotAnalysis({
        providerFixtureId,
        kickoffAt:
          fixture.kickoffAt,
        now,
      }),
    );
  }

  return {
    analyses,
    prioritizedFixtures,
    diagnostics: {
      version:
        CURRENT_RECOMMENDATION_BATCH_VERSION,
      requestedFixtures:
        uniqueFixtures.length,
      selectedFixtures:
        selectedFixtures.length,
      evaluatedFixtures:
        analyses.size,
      notEvaluatedFixtures:
        Math.max(
          0,
          uniqueFixtures.length -
            analyses.size,
        ),
      maximumFixtures,
      chunkSize,
      chunksPlanned:
        chunks.length,
      chunksCompleted,
      failedChunks,
      singleFixtureRetries,
      singleFixtureRetrySuccesses,
      missingProviderSnapshotClassifications:
        unclassifiedSelectedFixtureIds.length,
      recentRawAttemptFixtures:
        signals
          .recentRawAttemptFixtureIds
          .size,
      pitOddsFixtures:
        signals
          .pitOddsFixtureIds
          .size,
      checkpointPriorityFixtures:
        prioritizedFixtures.filter(
          (
            fixture:
              PrioritizedCurrentRecommendationFixture,
          ): boolean =>
            fixture.priorityReason ===
            'CHECKPOINT_NEAR',
        ).length,
      kickoffWithin6hFixtures:
        prioritizedFixtures.filter(
          (
            fixture:
              PrioritizedCurrentRecommendationFixture,
          ): boolean =>
            fixture
              .minutesToKickoff <=
            360,
        ).length,
      signalQueryError:
        signals.error,
      errors,
      strategy:
        'CHECKPOINT_RAW_ODDS_KICKOFF_CHUNKED_FAULT_ISOLATION',
      externalApiCalled:
        false,
      databaseWritten:
        false,
      realMoneyExecution:
        false,
    },
  };
}
