export const CURRENT_RECOMMENDATION_BATCH_VERSION =
  'v7.0-r4.10.2.5-current-recommendation-batch-v1';

export const CURRENT_RECOMMENDATION_PRIORITY_CHECKPOINTS =
  [180, 90, 60, 30, 10, 5] as const;

export interface CurrentRecommendationBatchFixture {
  providerFixtureId: number;
  kickoffAt: Date;
}

export interface CurrentRecommendationPrioritySignals {
  recentRawAttemptFixtureIds: ReadonlySet<number>;
  pitOddsFixtureIds: ReadonlySet<number>;
}

export type CurrentRecommendationPriorityReason =
  | 'CHECKPOINT_NEAR'
  | 'RECENT_RAW_ATTEMPT'
  | 'PIT_ODDS_AVAILABLE'
  | 'KICKOFF_WITHIN_6H'
  | 'UPCOMING_DEFAULT';

export interface PrioritizedCurrentRecommendationFixture
  extends CurrentRecommendationBatchFixture {
  minutesToKickoff: number;
  nearestCheckpointMinutes: number | null;
  checkpointDistanceMinutes: number | null;
  priorityReason: CurrentRecommendationPriorityReason;
  priorityRank: number;
  hasRecentRawAttempt: boolean;
  hasPitOdds: boolean;
}

function nearestCheckpoint(input: {
  minutesToKickoff: number;
  checkpoints: readonly number[];
}): {
  checkpointMinutes: number;
  distanceMinutes: number;
} | null {
  if (
    !Number.isFinite(
      input.minutesToKickoff,
    )
  ) {
    return null;
  }

  return (
    input.checkpoints
      .map(
        (
          checkpointMinutes: number,
        ) => ({
          checkpointMinutes,
          distanceMinutes:
            Math.abs(
              input.minutesToKickoff -
              checkpointMinutes,
            ),
        }),
      )
      .sort(
        (
          left,
          right,
        ): number =>
          left.distanceMinutes -
            right.distanceMinutes ||
          right.checkpointMinutes -
            left.checkpointMinutes,
      )[0] ??
    null
  );
}

export function prioritizeCurrentRecommendationFixtures(
  input: {
    fixtures: CurrentRecommendationBatchFixture[];
    now: Date;
    signals: CurrentRecommendationPrioritySignals;
    checkpointPriorityWindowMinutes?: number;
    checkpoints?: readonly number[];
  },
): PrioritizedCurrentRecommendationFixture[] {
  const checkpointPriorityWindowMinutes =
    input.checkpointPriorityWindowMinutes ??
    20;

  const checkpoints =
    input.checkpoints ??
    CURRENT_RECOMMENDATION_PRIORITY_CHECKPOINTS;

  return input.fixtures
    .filter(
      (
        fixture: CurrentRecommendationBatchFixture,
      ): boolean =>
        Number.isSafeInteger(
          fixture.providerFixtureId,
        ) &&
        fixture.providerFixtureId > 0 &&
        Number.isFinite(
          fixture.kickoffAt.getTime(),
        ) &&
        fixture.kickoffAt.getTime() >
          input.now.getTime(),
    )
    .map(
      (
        fixture: CurrentRecommendationBatchFixture,
      ): PrioritizedCurrentRecommendationFixture => {
        const minutesToKickoff =
          (
            fixture.kickoffAt.getTime() -
            input.now.getTime()
          ) /
          60_000;

        const nearest =
          nearestCheckpoint({
            minutesToKickoff,
            checkpoints,
          });

        const hasRecentRawAttempt =
          input.signals
            .recentRawAttemptFixtureIds
            .has(
              fixture.providerFixtureId,
            );

        const hasPitOdds =
          input.signals
            .pitOddsFixtureIds
            .has(
              fixture.providerFixtureId,
            );

        const checkpointNear =
          nearest != null &&
          nearest.distanceMinutes <=
            checkpointPriorityWindowMinutes;

        let priorityRank = 4;
        let priorityReason:
          CurrentRecommendationPriorityReason =
          'UPCOMING_DEFAULT';

        if (checkpointNear) {
          priorityRank = 0;
          priorityReason =
            'CHECKPOINT_NEAR';
        } else if (
          hasRecentRawAttempt
        ) {
          priorityRank = 1;
          priorityReason =
            'RECENT_RAW_ATTEMPT';
        } else if (hasPitOdds) {
          priorityRank = 2;
          priorityReason =
            'PIT_ODDS_AVAILABLE';
        } else if (
          minutesToKickoff <= 360
        ) {
          priorityRank = 3;
          priorityReason =
            'KICKOFF_WITHIN_6H';
        }

        return {
          ...fixture,
          minutesToKickoff,
          nearestCheckpointMinutes:
            nearest
              ?.checkpointMinutes ??
            null,
          checkpointDistanceMinutes:
            nearest
              ?.distanceMinutes ??
            null,
          priorityReason,
          priorityRank,
          hasRecentRawAttempt,
          hasPitOdds,
        };
      },
    )
    .sort(
      (
        left:
          PrioritizedCurrentRecommendationFixture,
        right:
          PrioritizedCurrentRecommendationFixture,
      ): number =>
        left.priorityRank -
          right.priorityRank ||
        (
          left.checkpointDistanceMinutes ??
          Number.POSITIVE_INFINITY
        ) -
          (
            right.checkpointDistanceMinutes ??
            Number.POSITIVE_INFINITY
          ) ||
        left.kickoffAt.getTime() -
          right.kickoffAt.getTime() ||
        left.providerFixtureId -
          right.providerFixtureId,
    );
}

export function chunkCurrentRecommendationFixtures<T>(
  values: T[],
  chunkSize: number,
): T[][] {
  if (
    !Number.isSafeInteger(
      chunkSize,
    ) ||
    chunkSize < 1
  ) {
    throw new RangeError(
      'chunkSize must be a positive integer.',
    );
  }

  const chunks: T[][] = [];

  for (
    let index = 0;
    index < values.length;
    index += chunkSize
  ) {
    chunks.push(
      values.slice(
        index,
        index + chunkSize,
      ),
    );
  }

  return chunks;
}

export function findUnclassifiedSelectedFixtureIds(
  selectedFixtureIds: number[],
  evaluatedFixtureIds: Iterable<number>,
): number[] {
  const evaluated =
    new Set<number>(
      evaluatedFixtureIds,
    );

  return selectedFixtureIds.filter(
    (
      providerFixtureId: number,
    ): boolean =>
      !evaluated.has(
        providerFixtureId,
      ),
  );
}

