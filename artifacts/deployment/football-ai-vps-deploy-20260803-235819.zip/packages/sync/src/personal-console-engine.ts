// R4.10.2.8.3_FIXTURE_ROW_RETURN_TYPE_HOTFIX: preserve the existing FixtureAnalysisRow return contract after explainability enrichment.
// R4.10.2.8_RECOMMENDATION_EXPLAINABILITY: API candidate wiring and status consistency; no official decision change.
import { prisma } from '@football-ai/database';

import { type CurrentScientificRecommendationAnalysis } from './current-scientific-recommendation-engine.js';

import {
  emptyCurrentRecommendationBatchDiagnostics,
  getPrioritizedCurrentRecommendationBatch,
  type CurrentRecommendationBatchDiagnostics,
} from './current-recommendation-batch-engine.js';

import {
  discoverCurrentPriorityCompetitions,
  isDemoCompetitionName,
  type CurrentCompetition,
  type CurrentCompetitionGroup,
} from './current-competition-discovery.js';

import { planUnallocatedScientificPaperStakes } from './bankroll-risk-engine.js';
import {
  collectFreshOddsDue,
  discoverFreshOddsFixtures,
  planFreshOddsCheckpoints,
} from './fresh-odds-collector-engine.js';
import { syncFixtures } from './fixtures.js';
import { syncPredictions } from './predictions.js';
import { getPersonalMarketMovementSummaries } from './personal-market-movement.js';
import {
  getPersonalTwoWayMarketMovements,
  type PersonalTwoWayMarketMovementSummary,
} from './personal-two-way-market-movement.js';
import { runLiveScientificPaperBetDecisions } from './real-odds-paper-bet-engine.js';
import { syncRepeatedFixtureContext } from './repeated-context.js';
import { attachCurrentRecommendationExplainability } from './current-recommendation-explainability.js';

export const PERSONAL_CONSOLE_VERSION = 'v7.0-personal-console-r4.7-early-odds-market-movement';

const DAY_MS = 86_400_000;
const DISPLAY_ODDS_MAX_AGE_MINUTES = 360;

type PredictionSource = 'SCIENTIFIC_DECISION' | 'API_FOOTBALL' | 'NONE';
type PersonalFixtureState = 'BEST_BET' | 'NO_BET' | 'PREDICTION_ONLY' | 'WAITING_DATA';

type PersonalCurrentRecommendationStatus =
  CurrentScientificRecommendationAnalysis['status'] | 'NOT_EVALUATED';

interface PersonalUpcomingOptions {
  now?: Date;
  days?: number;
  leagueIds?: number[];
  limit?: number;
}

interface PersonalRefreshOptions {
  days?: number;
  groups?: CurrentCompetitionGroup[];
}

interface FixtureLeagueRow {
  id: number;
  apiLeagueId: number;
  name: string;
  country: string | null;
  season: number;
  logoUrl: string | null;
}

interface TeamRow {
  id: number;
  apiTeamId: number;
  name: string;
  logoUrl: string | null;
}

interface ExternalPredictionRow {
  homeProbability: number | null;
  drawProbability: number | null;
  awayProbability: number | null;
  advice: string | null;
  predictedWinner: string | null;
  capturedAt: Date | null;
}

interface FixtureRow {
  id: number;
  apiFixtureId: number;
  kickoffAt: Date;
  round: string | null;
  leagueId: number;
  league: FixtureLeagueRow;
  homeTeam: TeamRow;
  awayTeam: TeamRow;
  externalPrediction: ExternalPredictionRow | null;
}

interface CandidateRow {
  marketType: string;
  selection: string;
  lineValue: number | null;
  decimalOdds: number;
  bookmakerName: string;
  modelProbability: number;
  fairMarketProbability: number;
  edge: number;
  expectedValue: number;
  reliabilityStatus: string;
  eligible: boolean;
  rejectionReasons: unknown;
}

interface DecisionRow {
  id: number;
  providerFixtureId: number;
  decisionType: string;
  horizonMinutes: number;
  decisionAsOf: Date;
  selectedMarket: string | null;
  selectedSelection: string | null;
  lineValue: number | null;
  decimalOdds: number | null;
  bookmakerName: string | null;
  modelProbability: number | null;
  fairMarketProbability: number | null;
  edge: number | null;
  expectedValue: number | null;
  reliabilityStatus: string | null;
  modelVersion: string;
  policyVersion: string;
  candidateCount: number;
  rejectedCandidateCount: number;
  candidates: CandidateRow[];
}

interface FreshCheckpointRow {
  providerFixtureId: number;
  horizonMinutes: number;
  horizonLabel: string;
  dueAt: Date;
  status: string;
  attemptedAt: Date | null;
  completedAt: Date | null;
  normalizedOdds: number;
  insertedOdds: number;
  pitUsableOdds: number;
  errorMessage: string | null;
}

interface OddsSnapshotRow {
  id: number;
  providerFixtureId: number;
  observedAt: Date;
  sourceUpdatedAt: Date | null;
  bookmakerId: number;
  bookmakerName: string;
  marketType: string;
  selection: string;
  lineValue: number | null;
  decimalOdds: number;
  pitUsable: boolean;
}

interface StakeRow {
  id: number;
  paperDecisionId: number;
  stakeDecisionType: string;
  stakingMode: string;
  stakeUnits: number;
  stakeFraction: number;
  riskBand: string;
  riskReasons: unknown;
  evaluatedAt: Date;
}

interface EnabledLeagueRow {
  id: number;
  apiLeagueId: number;
  name: string;
  country: string | null;
  season: number;
}

interface UpcomingFixtureIdRow {
  id: number;
}

interface CurrentLocalLeagueRow {
  id: number;
  apiLeagueId: number;
  season: number;
  name: string;
  country: string | null;
}

type ConsoleMarketCode = 'HDA' | 'BTTS' | 'OVER_UNDER_1_5' | 'OVER_UNDER_2_5' | 'OVER_UNDER_3_5';

type ConsoleMarketStatus =
  | 'BEST_BET'
  | 'ELIGIBLE_VALUE'
  | 'ANALYSIS_ONLY'
  | 'ODDS_AVAILABLE_WAITING_DECISION'
  | 'WAITING_ODDS';

type ConsoleMarketScientificType =
  'MATCH_WINNER' | 'BTTS' | 'TOTAL_GOALS_1_5' | 'TOTAL_GOALS_2_5' | 'TOTAL_GOALS_3_5';

type ConsoleMarketSelectionCode = 'HOME' | 'DRAW' | 'AWAY' | 'YES' | 'NO' | 'OVER' | 'UNDER';

interface ConsoleMarketDefinition {
  code: ConsoleMarketCode;
  scientificMarketType: ConsoleMarketScientificType;
  label: string;
  lineValue: number | null;
  selections: ConsoleMarketSelectionCode[];
}

interface ConsoleMarketSelection {
  code: ConsoleMarketSelectionCode;
  modelProbability: number | null;
  decimalOdds: number | null;
  bookmakerName: string | null;
  fairMarketProbability: number | null;
  edge: number | null;
  expectedValue: number | null;
  reliabilityStatus: string | null;
  eligible: boolean;
  rejectionReasons: unknown;
  oddsSource: 'SCIENTIFIC_CANDIDATE' | 'LATEST_SNAPSHOT' | 'NONE';
  oddsObservedAt: string | null;
  oddsSourceUpdatedAt: string | null;
  oddsSourceAgeMinutes: number | null;
  oddsPitUsable: boolean | null;
}

interface ConsoleMarketPrediction {
  code: ConsoleMarketCode;
  scientificMarketType: ConsoleMarketScientificType;
  label: string;
  lineValue: number | null;
  status: ConsoleMarketStatus;
  selectedAsBestBet: boolean;
  selections: ConsoleMarketSelection[];
}

interface FixtureAnalysisRow {
  fixture: {
    id: number;
    apiFixtureId: number;
    kickoffAt: string;
    round: string | null;
    league: {
      id: number;
      apiLeagueId: number;
      name: string;
      country: string | null;
      season: number;
      logoUrl: string | null;
    };
    homeTeam: {
      id: number;
      apiTeamId: number;
      name: string;
      logoUrl: string | null;
    };
    awayTeam: {
      id: number;
      apiTeamId: number;
      name: string;
      logoUrl: string | null;
    };
  };
  prediction: {
    source: PredictionSource;
    homeProbability: number | null;
    drawProbability: number | null;
    awayProbability: number | null;
    predictedSelection: 'HOME' | 'DRAW' | 'AWAY' | null;
    providerAdvice: string | null;
    providerPredictedWinner: string | null;
    providerCapturedAt: string | null;
  };
  scientificHda: {
    available: boolean;
    source: 'SCIENTIFIC_DECISION' | 'NONE';
    homeProbability: number | null;
    drawProbability: number | null;
    awayProbability: number | null;
    predictedSelection: 'HOME' | 'DRAW' | 'AWAY' | null;
    horizonMinutes: number | null;
    decisionAsOf: string | null;
    modelVersion: string | null;
  };
  providerHda: {
    available: boolean;
    source: 'API_FOOTBALL' | 'NONE';
    homeProbability: number | null;
    drawProbability: number | null;
    awayProbability: number | null;
    predictedSelection: 'HOME' | 'DRAW' | 'AWAY' | null;
    advice: string | null;
    predictedWinner: string | null;
    capturedAt: string | null;
  };
  decision: {
    id: number;
    decisionType: string;
    horizonMinutes: number;
    decisionAsOf: string;
    selectedMarket: string | null;
    selectedSelection: string | null;
    lineValue: number | null;
    decimalOdds: number | null;
    bookmakerName: string | null;
    modelProbability: number | null;
    fairMarketProbability: number | null;
    edge: number | null;
    expectedValue: number | null;
    reliabilityStatus: string | null;
    modelVersion: string;
    policyVersion: string;
    candidateCount: number;
    rejectedCandidateCount: number;
    candidates: Array<{
      marketType: string;
      selection: string;
      lineValue: number | null;
      decimalOdds: number;
      bookmakerName: string;
      modelProbability: number;
      fairMarketProbability: number;
      edge: number;
      expectedValue: number;
      reliabilityStatus: string;
      eligible: boolean;
      rejectionReasons: unknown;
    }>;
  } | null;
  stake: {
    stakeDecisionType: string;
    stakingMode: string;
    stakeUnits: number;
    stakeFraction: number;
    riskBand: string;
    riskReasons: unknown;
    evaluatedAt: string;
  } | null;
  nextCheckpoint: {
    horizonMinutes: number;
    horizonLabel: string;
    dueAt: string;
    status: string;
  } | null;
  marketPredictions: ConsoleMarketPrediction[];
  oddsDiagnostics: {
    snapshotRows: number;
    pitUsableRows: number;
    marketsWithOdds: number;
    latestObservedAt: string | null;
    latestSourceUpdatedAt: string | null;
    latestSourceAgeMinutes: number | null;
    latestCheckpoint: {
      horizonMinutes: number;
      horizonLabel: string;
      dueAt: string;
      status: string;
      attemptedAt: string | null;
      completedAt: string | null;
      normalizedOdds: number;
      insertedOdds: number;
      pitUsableOdds: number;
      errorMessage: string | null;
    } | null;
  };
  marketMovement: {
    source: 'API_FOOTBALL_PIT_SNAPSHOT';
    available: boolean;
    movementAvailable: boolean;
    bookmakerCount: number;
    matchedBookmakerCount: number;
    openingConsensus: {
      HOME: number;
      DRAW: number;
      AWAY: number;
    } | null;
    currentConsensus: {
      HOME: number;
      DRAW: number;
      AWAY: number;
    } | null;
    movement: {
      HOME: number;
      DRAW: number;
      AWAY: number;
    };
    recentMovement: {
      HOME: number;
      DRAW: number;
      AWAY: number;
    };
    steamMoveDetected: boolean;
    steamDirection: 'HOME' | 'DRAW' | 'AWAY' | 'NONE';
    steamStrength: number;
    lateMove: boolean;
    qualityScore: number;
    observedFrom: string | null;
    observedTo: string | null;
    reasons: string[];
  } | null;
  multiMarketMovements: PersonalTwoWayMarketMovementSummary[];
  currentRecommendationStatus: PersonalCurrentRecommendationStatus;
  currentRecommendationError: string | null;
  currentRecommendation: CurrentScientificRecommendationAnalysis['recommendation'];
  paperShadowRecommendation:
    CurrentScientificRecommendationAnalysis['paperShadowRecommendation'] | null;
  state: PersonalFixtureState;
}

function clampInteger(value: unknown, fallback: number, min: number, max: number): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(parsed)));
}

function uniquePositiveIntegers(value: unknown): number[] {
  if (!Array.isArray(value)) return [];
  return [
    ...new Set(
      value
        .map((item: unknown): number => Number(item))
        .filter((item: number): boolean => Number.isInteger(item) && item > 0),
    ),
  ];
}

function finiteNumber(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function sourceAgeMinutes(input: {
  observedAt: Date;
  sourceUpdatedAt: Date | null;
}): number | null {
  if (input.sourceUpdatedAt == null) return null;
  return Math.max(0, (input.observedAt.getTime() - input.sourceUpdatedAt.getTime()) / 60_000);
}

function oddsKey(input: {
  providerFixtureId: number;
  marketType: string;
  selection: string;
  lineValue: number | null;
}): string {
  return [
    input.providerFixtureId,
    input.marketType,
    input.selection,
    input.lineValue == null ? 'NULL' : input.lineValue.toFixed(3),
  ].join('|');
}

function providerSnapshotMarketType(
  definition: ConsoleMarketDefinition,
): 'MATCH_WINNER' | 'BTTS' | 'TOTAL_GOALS' {
  if (
    definition.scientificMarketType === 'TOTAL_GOALS_1_5' ||
    definition.scientificMarketType === 'TOTAL_GOALS_2_5' ||
    definition.scientificMarketType === 'TOTAL_GOALS_3_5'
  ) {
    // API-Football normalizes every full-match Goals Over/Under line
    // under one provider market and distinguishes 1.5 / 2.5 / 3.5
    // through lineValue.
    return 'TOTAL_GOALS';
  }

  return definition.scientificMarketType;
}

function latestOddsBySelection(rows: OddsSnapshotRow[]): Map<string, OddsSnapshotRow> {
  const latest = new Map<string, OddsSnapshotRow>();
  for (const row of rows) {
    const key = oddsKey(row);
    const current = latest.get(key);
    if (
      current == null ||
      row.observedAt.getTime() > current.observedAt.getTime() ||
      (row.observedAt.getTime() === current.observedAt.getTime() &&
        row.decimalOdds > current.decimalOdds)
    ) {
      latest.set(key, row);
    }
  }
  return latest;
}

function latestCheckpointForFixture(
  checkpoints: FreshCheckpointRow[],
  providerFixtureId: number,
): FreshCheckpointRow | null {
  return (
    checkpoints
      .filter((row: FreshCheckpointRow): boolean => row.providerFixtureId === providerFixtureId)
      .slice()
      .sort(
        (left: FreshCheckpointRow, right: FreshCheckpointRow): number =>
          right.dueAt.getTime() - left.dueAt.getTime(),
      )[0] ?? null
  );
}

function predictedSelection(input: {
  home: number | null;
  draw: number | null;
  away: number | null;
}): 'HOME' | 'DRAW' | 'AWAY' | null {
  const values: Array<{
    selection: 'HOME' | 'DRAW' | 'AWAY';
    probability: number | null;
  }> = [
    { selection: 'HOME', probability: input.home },
    { selection: 'DRAW', probability: input.draw },
    { selection: 'AWAY', probability: input.away },
  ];

  if (values.some((row: { probability: number | null }): boolean => row.probability == null)) {
    return null;
  }

  const ranked = values
    .slice()
    .sort(
      (
        left: { selection: 'HOME' | 'DRAW' | 'AWAY'; probability: number | null },
        right: { selection: 'HOME' | 'DRAW' | 'AWAY'; probability: number | null },
      ): number => (right.probability ?? 0) - (left.probability ?? 0),
    );

  return ranked[0]?.selection ?? null;
}

function probabilityFromCandidates(
  candidates: CandidateRow[],
  selection: 'HOME' | 'DRAW' | 'AWAY',
): number | null {
  const candidate = candidates.find(
    (row: CandidateRow): boolean =>
      row.marketType === 'MATCH_WINNER' && row.selection === selection,
  );
  return candidate ? finiteNumber(candidate.modelProbability) : null;
}

function nextCheckpoint(
  checkpoints: FreshCheckpointRow[],
  providerFixtureId: number,
): FreshCheckpointRow | null {
  const terminal = new Set(['SUCCESS', 'EMPTY', 'FAILED', 'SKIPPED']);
  return (
    checkpoints
      .filter(
        (row: FreshCheckpointRow): boolean =>
          row.providerFixtureId === providerFixtureId &&
          row.completedAt == null &&
          !terminal.has(row.status),
      )
      .sort(
        (left: FreshCheckpointRow, right: FreshCheckpointRow): number =>
          left.dueAt.getTime() - right.dueAt.getTime(),
      )[0] ?? null
  );
}

const CONSOLE_MARKETS: ConsoleMarketDefinition[] = [
  {
    code: 'HDA',
    scientificMarketType: 'MATCH_WINNER',
    label: 'HDA / 1X2',
    lineValue: null,
    selections: ['HOME', 'DRAW', 'AWAY'],
  },
  {
    code: 'BTTS',
    scientificMarketType: 'BTTS',
    label: 'BTTS',
    lineValue: null,
    selections: ['YES', 'NO'],
  },
  {
    code: 'OVER_UNDER_1_5',
    scientificMarketType: 'TOTAL_GOALS_1_5',
    label: 'Over / Under 1.5',
    lineValue: 1.5,
    selections: ['OVER', 'UNDER'],
  },
  {
    code: 'OVER_UNDER_2_5',
    scientificMarketType: 'TOTAL_GOALS_2_5',
    label: 'Over / Under 2.5',
    lineValue: 2.5,
    selections: ['OVER', 'UNDER'],
  },
  {
    code: 'OVER_UNDER_3_5',
    scientificMarketType: 'TOTAL_GOALS_3_5',
    label: 'Over / Under 3.5',
    lineValue: 3.5,
    selections: ['OVER', 'UNDER'],
  },
];

function buildConsoleMarketPredictions(input: {
  decision: DecisionRow | null;
  candidates: CandidateRow[];
  providerFixtureId: number;
  latestOdds: Map<string, OddsSnapshotRow>;
}): ConsoleMarketPrediction[] {
  return CONSOLE_MARKETS.map((definition: ConsoleMarketDefinition): ConsoleMarketPrediction => {
    const marketCandidates = input.candidates.filter(
      (candidate: CandidateRow): boolean =>
        candidate.marketType === definition.scientificMarketType,
    );
    const selectedAsBestBet =
      input.decision?.decisionType === 'BEST_BET' &&
      input.decision.selectedMarket === definition.scientificMarketType;
    const hasEligibleValue = marketCandidates.some(
      (candidate: CandidateRow): boolean => candidate.eligible,
    );
    const marketHasSnapshotOdds = definition.selections.some(
      (selection: ConsoleMarketSelectionCode): boolean =>
        input.latestOdds.has(
          oddsKey({
            providerFixtureId: input.providerFixtureId,
            marketType: providerSnapshotMarketType(definition),
            selection,
            lineValue: definition.lineValue,
          }),
        ),
    );
    const status: ConsoleMarketStatus = selectedAsBestBet
      ? 'BEST_BET'
      : hasEligibleValue
        ? 'ELIGIBLE_VALUE'
        : marketCandidates.length > 0
          ? 'ANALYSIS_ONLY'
          : marketHasSnapshotOdds
            ? 'ODDS_AVAILABLE_WAITING_DECISION'
            : 'WAITING_ODDS';
    const selections = definition.selections.map(
      (selection: ConsoleMarketSelectionCode): ConsoleMarketSelection => {
        const candidate = marketCandidates
          .filter((row: CandidateRow): boolean => row.selection === selection)
          .slice()
          .sort(
            (left: CandidateRow, right: CandidateRow): number =>
              right.expectedValue - left.expectedValue || right.decimalOdds - left.decimalOdds,
          )[0];
        const snapshot =
          input.latestOdds.get(
            oddsKey({
              providerFixtureId: input.providerFixtureId,
              marketType: providerSnapshotMarketType(definition),
              selection,
              lineValue: definition.lineValue,
            }),
          ) ?? null;
        const observedAt = snapshot?.observedAt ?? null;
        const sourceUpdatedAt = snapshot?.sourceUpdatedAt ?? null;
        return {
          code: selection,
          modelProbability: candidate?.modelProbability ?? null,
          decimalOdds: candidate?.decimalOdds ?? snapshot?.decimalOdds ?? null,
          bookmakerName: candidate?.bookmakerName ?? snapshot?.bookmakerName ?? null,
          fairMarketProbability: candidate?.fairMarketProbability ?? null,
          edge: candidate?.edge ?? null,
          expectedValue: candidate?.expectedValue ?? null,
          reliabilityStatus:
            candidate?.reliabilityStatus ??
            (snapshot != null ? 'WAITING_SCIENTIFIC_DECISION' : null),
          eligible: candidate?.eligible ?? false,
          rejectionReasons: candidate?.rejectionReasons ?? [],
          oddsSource:
            candidate != null
              ? 'SCIENTIFIC_CANDIDATE'
              : snapshot != null
                ? 'LATEST_SNAPSHOT'
                : 'NONE',
          oddsObservedAt: observedAt?.toISOString() ?? null,
          oddsSourceUpdatedAt: sourceUpdatedAt?.toISOString() ?? null,
          oddsSourceAgeMinutes:
            observedAt == null ? null : sourceAgeMinutes({ observedAt, sourceUpdatedAt }),
          oddsPitUsable: snapshot?.pitUsable ?? null,
        };
      },
    );
    return {
      code: definition.code,
      scientificMarketType: definition.scientificMarketType,
      label: definition.label,
      lineValue: definition.lineValue,
      status,
      selectedAsBestBet,
      selections,
    };
  });
}

export async function getPersonalUpcomingAnalysis(
  options: PersonalUpcomingOptions = {},
): Promise<Record<string, unknown>> {
  const now = options.now ?? new Date();
  const days = clampInteger(options.days, 14, 1, 30);
  const limit = clampInteger(options.limit, 120, 1, 300);
  const leagueIds = uniquePositiveIntegers(options.leagueIds);
  const until = new Date(now.getTime() + days * DAY_MS);

  const rawFixtures = (await prisma.fixture.findMany({
    where: {
      status: 'UPCOMING',
      kickoffAt: { gt: now, lte: until },
      ...(leagueIds.length > 0 ? { leagueId: { in: leagueIds } } : {}),
    },
    include: {
      league: true,
      homeTeam: true,
      awayTeam: true,
      externalPrediction: true,
    },
    orderBy: { kickoffAt: 'asc' },
    take: Math.min(1000, limit * 4),
  })) as FixtureRow[];

  const minimumSeason = now.getUTCFullYear() - 1;
  const fixtures = rawFixtures
    .filter(
      (fixture: FixtureRow): boolean =>
        fixture.apiFixtureId > 0 &&
        fixture.league.season >= minimumSeason &&
        !isDemoCompetitionName(fixture.league.name),
    )
    .slice(0, limit);

  const providerFixtureIds = fixtures.map((fixture: FixtureRow): number => fixture.apiFixtureId);

  let currentRecommendationByFixture = new Map<number, CurrentScientificRecommendationAnalysis>();

  let currentRecommendationBatchDiagnostics: CurrentRecommendationBatchDiagnostics =
    emptyCurrentRecommendationBatchDiagnostics(providerFixtureIds.length);

  try {
    const currentRecommendationBatch = await getPrioritizedCurrentRecommendationBatch({
      fixtures: fixtures.map((fixture: FixtureRow) => ({
        providerFixtureId: fixture.apiFixtureId,
        kickoffAt: fixture.kickoffAt,
      })),
      now,
    });

    currentRecommendationByFixture = currentRecommendationBatch.analyses;

    currentRecommendationBatchDiagnostics = currentRecommendationBatch.diagnostics;
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);

    currentRecommendationBatchDiagnostics = emptyCurrentRecommendationBatchDiagnostics(
      providerFixtureIds.length,
      reason,
    );

    console.error(
      JSON.stringify({
        event: 'personal-current-recommendation-batch-error',
        reason,
      }),
    );
  }

  let decisionRows: DecisionRow[] = [];
  let checkpointRows: FreshCheckpointRow[] = [];
  let oddsRows: OddsSnapshotRow[] = [];

  if (providerFixtureIds.length > 0) {
    const minimumOddsObservedAt = new Date(now.getTime() - DISPLAY_ODDS_MAX_AGE_MINUTES * 60_000);
    const [rawDecisions, rawCheckpoints, rawOddsRows] = await Promise.all([
      prisma.scientificPaperBetDecision.findMany({
        where: { providerFixtureId: { in: providerFixtureIds }, kickoffAt: { gt: now } },
        include: { candidates: true },
        orderBy: [{ decisionAsOf: 'desc' }, { id: 'desc' }],
      }),
      prisma.apiFootballFreshOddsCheckpoint.findMany({
        where: { providerFixtureId: { in: providerFixtureIds } },
        select: {
          providerFixtureId: true,
          horizonMinutes: true,
          horizonLabel: true,
          dueAt: true,
          status: true,
          attemptedAt: true,
          completedAt: true,
          normalizedOdds: true,
          insertedOdds: true,
          pitUsableOdds: true,
          errorMessage: true,
        },
        orderBy: [{ dueAt: 'asc' }, { id: 'asc' }],
      }),
      prisma.apiFootballOddsSnapshot.findMany({
        where: {
          providerFixtureId: { in: providerFixtureIds },
          observedAt: { gte: minimumOddsObservedAt, lte: now },
        },
        select: {
          id: true,
          providerFixtureId: true,
          observedAt: true,
          sourceUpdatedAt: true,
          bookmakerId: true,
          bookmakerName: true,
          marketType: true,
          selection: true,
          lineValue: true,
          decimalOdds: true,
          pitUsable: true,
        },
        orderBy: [{ observedAt: 'desc' }, { decimalOdds: 'desc' }, { id: 'desc' }],
        take: 20000,
      }),
    ]);
    decisionRows = rawDecisions as DecisionRow[];
    checkpointRows = rawCheckpoints as FreshCheckpointRow[];
    oddsRows = rawOddsRows as OddsSnapshotRow[];
  }

  const latestOdds = latestOddsBySelection(oddsRows);

  const latestDecisionByFixture = new Map<number, DecisionRow>();
  for (const decision of decisionRows) {
    if (!latestDecisionByFixture.has(decision.providerFixtureId)) {
      latestDecisionByFixture.set(decision.providerFixtureId, decision);
    }
  }

  const decisionIds = [...latestDecisionByFixture.values()].map(
    (decision: DecisionRow): number => decision.id,
  );

  const stakeRows =
    decisionIds.length === 0
      ? []
      : ((await prisma.scientificPaperStakeDecision.findMany({
          where: { paperDecisionId: { in: decisionIds } },
          orderBy: [{ evaluatedAt: 'desc' }, { id: 'desc' }],
        })) as StakeRow[]);

  const latestStakeByDecision = new Map<number, StakeRow>();
  for (const stake of stakeRows) {
    if (!latestStakeByDecision.has(stake.paperDecisionId)) {
      latestStakeByDecision.set(stake.paperDecisionId, stake);
    }
  }

  const marketMovementByFixture = await getPersonalMarketMovementSummaries({
    fixtures: fixtures.map((fixture: FixtureRow) => ({
      localFixtureId: fixture.id,
      providerFixtureId: fixture.apiFixtureId,
      kickoffAt: fixture.kickoffAt,
    })),
    predictionAsOf: now,
  });

  const multiMarketMovementByFixture = await getPersonalTwoWayMarketMovements({
    fixtures: fixtures.map((fixture: FixtureRow) => ({
      providerFixtureId: fixture.apiFixtureId,
      kickoffAt: fixture.kickoffAt,
    })),
    predictionAsOf: now,
  });

  const rows: FixtureAnalysisRow[] = fixtures.map((fixture: FixtureRow): FixtureAnalysisRow => {
    const decision = latestDecisionByFixture.get(fixture.apiFixtureId) ?? null;
    const currentScientific = currentRecommendationByFixture.get(fixture.apiFixtureId) ?? null;
    const candidates: CandidateRow[] = decision?.candidates ?? [];
    const providerPrediction = fixture.externalPrediction;

    const scientificProbabilities = {
      home: probabilityFromCandidates(candidates, 'HOME'),
      draw: probabilityFromCandidates(candidates, 'DRAW'),
      away: probabilityFromCandidates(candidates, 'AWAY'),
    };
    const scientificProbabilityComplete =
      scientificProbabilities.home != null &&
      scientificProbabilities.draw != null &&
      scientificProbabilities.away != null;

    const scientificSelectedPrediction = scientificProbabilityComplete
      ? predictedSelection(scientificProbabilities)
      : null;

    const providerProbabilities = {
      home: finiteNumber(providerPrediction?.homeProbability),
      draw: finiteNumber(providerPrediction?.drawProbability),
      away: finiteNumber(providerPrediction?.awayProbability),
    };
    const providerProbabilityComplete =
      providerProbabilities.home != null &&
      providerProbabilities.draw != null &&
      providerProbabilities.away != null;
    const providerSelectedPrediction = providerProbabilityComplete
      ? predictedSelection(providerProbabilities)
      : null;

    const predictionSource: PredictionSource = scientificProbabilityComplete
      ? 'SCIENTIFIC_DECISION'
      : providerPrediction
        ? 'API_FOOTBALL'
        : 'NONE';

    const probabilities = scientificProbabilityComplete
      ? scientificProbabilities
      : providerProbabilities;

    const selectedPrediction = predictedSelection(probabilities);
    const stake = decision ? (latestStakeByDecision.get(decision.id) ?? null) : null;
    const checkpoint = nextCheckpoint(checkpointRows, fixture.apiFixtureId);
    const marketPredictions = buildConsoleMarketPredictions({
      decision,
      candidates,
      providerFixtureId: fixture.apiFixtureId,
      latestOdds,
    });
    const marketMovement = marketMovementByFixture.get(fixture.apiFixtureId) ?? null;
    const multiMarketMovements = multiMarketMovementByFixture.get(fixture.apiFixtureId) ?? [];
    const fixtureOddsRows = oddsRows.filter(
      (row: OddsSnapshotRow): boolean => row.providerFixtureId === fixture.apiFixtureId,
    );
    const latestObservedRow =
      fixtureOddsRows
        .slice()
        .sort(
          (left: OddsSnapshotRow, right: OddsSnapshotRow): number =>
            right.observedAt.getTime() - left.observedAt.getTime(),
        )[0] ?? null;
    const latestCheckpoint = latestCheckpointForFixture(checkpointRows, fixture.apiFixtureId);
    const oddsDiagnostics = {
      snapshotRows: fixtureOddsRows.length,
      pitUsableRows: fixtureOddsRows.filter((row: OddsSnapshotRow): boolean => row.pitUsable)
        .length,
      marketsWithOdds: new Set(
        fixtureOddsRows.map((row: OddsSnapshotRow): string => row.marketType),
      ).size,
      latestObservedAt: latestObservedRow?.observedAt.toISOString() ?? null,
      latestSourceUpdatedAt: latestObservedRow?.sourceUpdatedAt?.toISOString() ?? null,
      latestSourceAgeMinutes:
        latestObservedRow == null
          ? null
          : sourceAgeMinutes({
              observedAt: latestObservedRow.observedAt,
              sourceUpdatedAt: latestObservedRow.sourceUpdatedAt,
            }),
      latestCheckpoint: latestCheckpoint
        ? {
            horizonMinutes: latestCheckpoint.horizonMinutes,
            horizonLabel: latestCheckpoint.horizonLabel,
            dueAt: latestCheckpoint.dueAt.toISOString(),
            status: latestCheckpoint.status,
            attemptedAt: latestCheckpoint.attemptedAt?.toISOString() ?? null,
            completedAt: latestCheckpoint.completedAt?.toISOString() ?? null,
            normalizedOdds: latestCheckpoint.normalizedOdds,
            insertedOdds: latestCheckpoint.insertedOdds,
            pitUsableOdds: latestCheckpoint.pitUsableOdds,
            errorMessage: latestCheckpoint.errorMessage,
          }
        : null,
    };

    const state: PersonalFixtureState =
      decision?.decisionType === 'BEST_BET'
        ? 'BEST_BET'
        : decision?.decisionType === 'NO_BET'
          ? 'NO_BET'
          : predictionSource === 'NONE'
            ? 'WAITING_DATA'
            : 'PREDICTION_ONLY';

    return attachCurrentRecommendationExplainability(
      {
        fixture: {
          id: fixture.id,
          apiFixtureId: fixture.apiFixtureId,
          kickoffAt: fixture.kickoffAt.toISOString(),
          round: fixture.round,
          league: {
            id: fixture.league.id,
            apiLeagueId: fixture.league.apiLeagueId,
            name: fixture.league.name,
            country: fixture.league.country,
            season: fixture.league.season,
            logoUrl: fixture.league.logoUrl,
          },
          homeTeam: {
            id: fixture.homeTeam.id,
            apiTeamId: fixture.homeTeam.apiTeamId,
            name: fixture.homeTeam.name,
            logoUrl: fixture.homeTeam.logoUrl,
          },
          awayTeam: {
            id: fixture.awayTeam.id,
            apiTeamId: fixture.awayTeam.apiTeamId,
            name: fixture.awayTeam.name,
            logoUrl: fixture.awayTeam.logoUrl,
          },
        },
        prediction: {
          source: predictionSource,
          homeProbability: probabilities.home,
          drawProbability: probabilities.draw,
          awayProbability: probabilities.away,
          predictedSelection: selectedPrediction,
          providerAdvice: providerPrediction?.advice ?? null,
          providerPredictedWinner: providerPrediction?.predictedWinner ?? null,
          providerCapturedAt: providerPrediction?.capturedAt?.toISOString() ?? null,
        },
        scientificHda: {
          available: scientificProbabilityComplete,
          source: scientificProbabilityComplete ? 'SCIENTIFIC_DECISION' : 'NONE',
          homeProbability: scientificProbabilityComplete ? scientificProbabilities.home : null,
          drawProbability: scientificProbabilityComplete ? scientificProbabilities.draw : null,
          awayProbability: scientificProbabilityComplete ? scientificProbabilities.away : null,
          predictedSelection: scientificSelectedPrediction,
          horizonMinutes: scientificProbabilityComplete ? (decision?.horizonMinutes ?? null) : null,
          decisionAsOf: scientificProbabilityComplete
            ? (decision?.decisionAsOf.toISOString() ?? null)
            : null,
          modelVersion: scientificProbabilityComplete ? (decision?.modelVersion ?? null) : null,
        },
        providerHda: {
          available: providerProbabilityComplete,
          source: providerProbabilityComplete ? 'API_FOOTBALL' : 'NONE',
          homeProbability: providerProbabilities.home,
          drawProbability: providerProbabilities.draw,
          awayProbability: providerProbabilities.away,
          predictedSelection: providerSelectedPrediction,
          advice: providerPrediction?.advice ?? null,
          predictedWinner: providerPrediction?.predictedWinner ?? null,
          capturedAt: providerPrediction?.capturedAt?.toISOString() ?? null,
        },
        decision: decision
          ? {
              id: decision.id,
              decisionType: decision.decisionType,
              horizonMinutes: decision.horizonMinutes,
              decisionAsOf: decision.decisionAsOf.toISOString(),
              selectedMarket: decision.selectedMarket,
              selectedSelection: decision.selectedSelection,
              lineValue: decision.lineValue,
              decimalOdds: decision.decimalOdds,
              bookmakerName: decision.bookmakerName,
              modelProbability: decision.modelProbability,
              fairMarketProbability: decision.fairMarketProbability,
              edge: decision.edge,
              expectedValue: decision.expectedValue,
              reliabilityStatus: decision.reliabilityStatus,
              modelVersion: decision.modelVersion,
              policyVersion: decision.policyVersion,
              candidateCount: decision.candidateCount,
              rejectedCandidateCount: decision.rejectedCandidateCount,
              candidates: candidates
                .slice()
                .sort(
                  (left: CandidateRow, right: CandidateRow): number =>
                    right.expectedValue - left.expectedValue,
                )
                .slice(0, 12)
                .map((candidate: CandidateRow) => ({
                  marketType: candidate.marketType,
                  selection: candidate.selection,
                  lineValue: candidate.lineValue,
                  decimalOdds: candidate.decimalOdds,
                  bookmakerName: candidate.bookmakerName,
                  modelProbability: candidate.modelProbability,
                  fairMarketProbability: candidate.fairMarketProbability,
                  edge: candidate.edge,
                  expectedValue: candidate.expectedValue,
                  reliabilityStatus: candidate.reliabilityStatus,
                  eligible: candidate.eligible,
                  rejectionReasons: candidate.rejectionReasons,
                })),
            }
          : null,
        stake: stake
          ? {
              stakeDecisionType: stake.stakeDecisionType,
              stakingMode: stake.stakingMode,
              stakeUnits: stake.stakeUnits,
              stakeFraction: stake.stakeFraction,
              riskBand: stake.riskBand,
              riskReasons: stake.riskReasons,
              evaluatedAt: stake.evaluatedAt.toISOString(),
            }
          : null,
        nextCheckpoint: checkpoint
          ? {
              horizonMinutes: checkpoint.horizonMinutes,
              horizonLabel: checkpoint.horizonLabel,
              dueAt: checkpoint.dueAt.toISOString(),
              status: checkpoint.status,
            }
          : null,
        marketPredictions,
        marketMovement,
        multiMarketMovements,
        oddsDiagnostics,
        currentRecommendationStatus: currentScientific?.status ?? 'NOT_EVALUATED',
        currentRecommendationError: currentScientific?.error ?? null,
        currentRecommendation: currentScientific?.recommendation ?? null,
        paperShadowRecommendation: currentScientific?.paperShadowRecommendation ?? null,
        state,
      },
      currentScientific,
    ) as FixtureAnalysisRow;
  });

  const bestBets = rows
    .filter((row: FixtureAnalysisRow): boolean => row.state === 'BEST_BET')
    .sort(
      (left: FixtureAnalysisRow, right: FixtureAnalysisRow): number =>
        (right.decision?.expectedValue ?? -999) - (left.decision?.expectedValue ?? -999) ||
        (right.decision?.edge ?? -999) - (left.decision?.edge ?? -999),
    );

  const leagues = [
    ...new Map(
      fixtures.map((fixture: FixtureRow) => [
        fixture.league.id,
        {
          id: fixture.league.id,
          apiLeagueId: fixture.league.apiLeagueId,
          name: fixture.league.name,
          country: fixture.league.country,
          season: fixture.league.season,
          logoUrl: fixture.league.logoUrl,
        },
      ]),
    ).values(),
  ];

  return {
    version: PERSONAL_CONSOLE_VERSION,
    generatedAt: new Date().toISOString(),
    window: {
      from: now.toISOString(),
      to: until.toISOString(),
      days,
    },
    counts: {
      fixtures: rows.length,
      predicted: rows.filter((row: FixtureAnalysisRow): boolean => row.prediction.source !== 'NONE')
        .length,
      scientificDecisions: rows.filter((row: FixtureAnalysisRow): boolean => row.decision != null)
        .length,
      bestBets: bestBets.length,
      currentRecommendations: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.currentRecommendation != null,
      ).length,
      paperRecommendations: rows.filter(
        (row: FixtureAnalysisRow): boolean =>
          row.paperShadowRecommendation?.selected?.paperTrackEligible === true,
      ).length,
      noBets: rows.filter((row: FixtureAnalysisRow): boolean => row.state === 'NO_BET').length,
      predictionOnly: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.state === 'PREDICTION_ONLY',
      ).length,
      waitingData: rows.filter((row: FixtureAnalysisRow): boolean => row.state === 'WAITING_DATA')
        .length,
      fixturesWithOdds: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.oddsDiagnostics.snapshotRows > 0,
      ).length,
      fixturesWithPitUsableOdds: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.oddsDiagnostics.pitUsableRows > 0,
      ).length,
      scientificHdaReady: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.scientificHda.available,
      ).length,
      providerHdaAvailable: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.providerHda.available,
      ).length,
      fixturesWithMarketMovement: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.marketMovement?.movementAvailable === true,
      ).length,
      fixturesWithMultiMarketMovement: rows.filter((row: FixtureAnalysisRow): boolean =>
        row.multiMarketMovements.some(
          (movement: PersonalTwoWayMarketMovementSummary): boolean => movement.movementAvailable,
        ),
      ).length,
    },
    currentRecommendationBatch: currentRecommendationBatchDiagnostics,
    currentRecommendationStatusCounts: {
      AVAILABLE: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.currentRecommendationStatus === 'AVAILABLE',
      ).length,
      NO_FRESH_PIT_ODDS: rows.filter(
        (row: FixtureAnalysisRow): boolean =>
          row.currentRecommendationStatus === 'NO_FRESH_PIT_ODDS',
      ).length,
      NO_PROVIDER_FIXTURE_SNAPSHOT: rows.filter(
        (row: FixtureAnalysisRow): boolean =>
          row.currentRecommendationStatus === 'NO_PROVIDER_FIXTURE_SNAPSHOT',
      ).length,
      NO_MODEL: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.currentRecommendationStatus === 'NO_MODEL',
      ).length,
      NO_COMPLETE_MARKET: rows.filter(
        (row: FixtureAnalysisRow): boolean =>
          row.currentRecommendationStatus === 'NO_COMPLETE_MARKET',
      ).length,
      NO_VALUE_SIGNAL: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.currentRecommendationStatus === 'NO_VALUE_SIGNAL',
      ).length,
      UNMAPPED_FIXTURE: rows.filter(
        (row: FixtureAnalysisRow): boolean =>
          row.currentRecommendationStatus === 'UNMAPPED_FIXTURE',
      ).length,
      MAPPING_MISMATCH: rows.filter(
        (row: FixtureAnalysisRow): boolean =>
          row.currentRecommendationStatus === 'MAPPING_MISMATCH',
      ).length,
      NOT_EVALUATED: rows.filter(
        (row: FixtureAnalysisRow): boolean => row.currentRecommendationStatus === 'NOT_EVALUATED',
      ).length,
    },
    leagues,
    topBestBets: bestBets.slice(0, 8),
    fixtures: rows,
    integrity: {
      personalMode: true,
      readOnlyAnalysis: true,
      predictionIsNotBestBet: true,
      currentRecommendationIsShadowSignal: true,
      currentRecommendationDoesNotChangeBestBet: true,
      recommendationStatusDashboard: true,
      currentRecommendationBatchPriority: true,
      currentRecommendationChunkFaultIsolation: true,
      missingProviderSnapshotTerminalClassification: true,
      longshotBiasGuardRiskAdjustedRanking: true,
      completeRecommendationCoverage: true,
      bestBetComesOnlyFromScientificPaperDecision: true,
      syntheticOddsUsed: false,
      realMoneyExecution: false,
      automaticBetPlacement: false,
      automaticPromotion: false,
      providerPredictionNeverLabeledAsScientificModel: true,
      scientificHdaNeverFallsBackToProvider: true,
      earlyOddsDoNotCreateBestBet: true,
      marketMovementUsesPitSnapshotsOnly: true,
      multiMarketMovementUsesPitSnapshotsOnly: true,
      multiMarketMovementDoesNotChangeBestBet: true,
    },
  };
}

export async function refreshPersonalUpcomingAnalysis(
  options: PersonalRefreshOptions = {},
): Promise<Record<string, unknown>> {
  const now = new Date();
  const days = clampInteger(options.days, 14, 1, 30);
  const to = new Date(now.getTime() + days * DAY_MS);

  const discovery = await discoverCurrentPriorityCompetitions({
    groups: options.groups,
    maximumSea: 8,
    maximumAsia: 8,
  });

  if (discovery.competitions.length === 0) {
    throw new Error('NO_CURRENT_PRIORITY_COMPETITIONS_FOUND');
  }

  const configurations = discovery.competitions.map((competition: CurrentCompetition) => ({
    leagueId: competition.apiLeagueId,
    season: competition.season,
  }));

  const fixtureSync = await syncFixtures({
    from: now.toISOString().slice(0, 10),
    to: to.toISOString().slice(0, 10),
    leagueConfigurations: configurations,
  });

  const currentLocalLeagues = (await prisma.league.findMany({
    where: {
      OR: discovery.competitions.map((competition: CurrentCompetition) => ({
        apiLeagueId: competition.apiLeagueId,
        season: competition.season,
      })),
    },
    select: {
      id: true,
      apiLeagueId: true,
      season: true,
      name: true,
      country: true,
    },
  })) as CurrentLocalLeagueRow[];

  const currentLocalLeagueIds = currentLocalLeagues
    .filter((league: CurrentLocalLeagueRow): boolean => !isDemoCompetitionName(league.name))
    .map((league: CurrentLocalLeagueRow): number => league.id);

  const upcomingFixtures = (await prisma.fixture.findMany({
    where: {
      leagueId: { in: currentLocalLeagueIds },
      status: 'UPCOMING',
      kickoffAt: { gt: now, lte: to },
    },
    select: { id: true },
    orderBy: { kickoffAt: 'asc' },
    take: 120,
  })) as UpcomingFixtureIdRow[];

  const predictionSync = await syncPredictions({
    fixtureIds: upcomingFixtures.map((fixture: UpcomingFixtureIdRow): number => fixture.id),
  });

  const contextSync = await syncRepeatedFixtureContext({
    now,
  });

  const providerLeagueIds = discovery.competitions
    .map((competition: CurrentCompetition): number => competition.apiLeagueId)
    .join(',');

  const previousFreshLeagueIds = process.env.FRESH_ODDS_LEAGUE_IDS;
  let freshDiscovery: unknown;

  try {
    process.env.FRESH_ODDS_LEAGUE_IDS = providerLeagueIds;
    freshDiscovery = await discoverFreshOddsFixtures();
  } finally {
    if (previousFreshLeagueIds == null) {
      delete process.env.FRESH_ODDS_LEAGUE_IDS;
    } else {
      process.env.FRESH_ODDS_LEAGUE_IDS = previousFreshLeagueIds;
    }
  }

  const freshPlan = await planFreshOddsCheckpoints(now);
  const freshCollect = await collectFreshOddsDue(now);
  const paperDecisions = await runLiveScientificPaperBetDecisions({ now });

  let riskOverlay: unknown;
  try {
    riskOverlay = await planUnallocatedScientificPaperStakes({ limit: 300 });
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    if (!reason.startsWith('NO_FROZEN_RISK_POLICY')) throw error;
    riskOverlay = {
      status: 'SKIPPED',
      reason,
      realMoneyExecution: false,
    };
  }

  const analysis = await getPersonalUpcomingAnalysis({
    now: new Date(),
    days,
    leagueIds: currentLocalLeagueIds,
    limit: 300,
  });

  return {
    version: PERSONAL_CONSOLE_VERSION,
    command: 'refresh-current-only',
    startedAt: now.toISOString(),
    finishedAt: new Date().toISOString(),
    discovery: {
      source: 'API_FOOTBALL_CURRENT_TRUE',
      apiRequests: discovery.apiRequests,
      quotaRemainingDay: discovery.quotaRemainingDay,
      quotaRemainingMinute: discovery.quotaRemainingMinute,
      competitions: discovery.competitions,
    },
    fixtureSync,
    predictionSync,
    contextSync,
    freshDiscovery,
    freshPlan,
    freshCollect,
    paperDecisions,
    riskOverlay,
    analysis,
    safety: {
      currentFixturesOnly: true,
      demoCompetitionsExcluded: true,
      pastFixturesExcludedFromPredictions: true,
      personalMode: true,
      adminTokenRequired: false,
      externalApiCalled: true,
      databaseWritten: true,
      syntheticOddsUsed: false,
      automaticBetPlacement: false,
      realMoneyExecution: false,
      automaticPromotion: false,
    },
  };
}
