import Link from 'next/link';

import { apiFetch } from '../lib/api';
import type { PersonalUpcomingAnalysisDto } from '../lib/personal-types';
import type { DashboardStats } from '../lib/types';

function pct(value: number | null): string {
  return value == null ? '—' : `${(value * 100).toFixed(1)}%`;
}

export default async function HomePage() {
  const [stats, analysis] = await Promise.all([
    apiFetch<DashboardStats>('/stats'),
    apiFetch<PersonalUpcomingAnalysisDto>('/personal/upcoming-analysis?days=7&limit=120'),
  ]);

  return (
    <div className="pcr-home">
      <section className="pcr-hero">
        <div>
          <span className="eyebrow">FOOTBALL AI V7 · PERSONAL</span>
          <h1>Dự đoán, BEST BET và backtest trên một giao diện</h1>
          <p>
            Dùng prediction để hiểu trận đấu; dùng scientific value policy để quyết định BEST BET;
            dùng backtest point-in-time để kiểm chứng model trước khi tin kết quả.
          </p>
          <div className="hero-actions">
            <Link className="button primary" href="/predictions">
              Xem trận sắp tới
            </Link>
            <Link className="button secondary" href="/backtest">
              Mở Backtest Lab
            </Link>
          </div>
        </div>

        <div className="pcr-principles">
          <span>Nguyên tắc</span>
          <strong>Prediction ≠ BEST BET</strong>
          <strong>BEST BET cần odds + edge + EV + reliability</strong>
          <small>Paper/research only · không auto-bet</small>
        </div>
      </section>

      <section className="pcr-kpis">
        <div><span>Trận 7 ngày tới</span><strong>{analysis.counts.fixtures}</strong><small>{analysis.counts.predicted} có prediction</small></div>
        <div className="highlight"><span>BEST BET</span><strong>{analysis.counts.bestBets}</strong><small>scientific decision</small></div>
        <div><span>NO BET</span><strong>{analysis.counts.noBets}</strong><small>không đủ value</small></div>
        <div><span>Prediction-only</span><strong>{analysis.counts.predictionOnly}</strong><small>chưa phải kèo</small></div>
        <div><span>Paper hit rate</span><strong>{pct(stats.hitRate)}</strong><small>{stats.wins}W / {stats.losses}L</small></div>
      </section>

      <section className="pcr-home-grid">
        <Link href="/predictions" className="pcr-home-card">
          <span className="eyebrow">01</span>
          <h2>Dự đoán & BEST BET</h2>
          <p>
            Trận hiện tại gồm ASEAN Championship, Đông Nam Á, châu Á, Premier League và La Liga;
            có HDA, BTTS, Over/Under, BEST BET, Edge, EV và stake overlay.
          </p>
          <b>Mở dự đoán →</b>
        </Link>

        <Link href="/backtest" className="pcr-home-card">
          <span className="eyebrow">02</span>
          <h2>Backtest nhiều giải</h2>
          <p>Không cần admin token. Chạy tối đa 16 giải một lượt và so sánh kết quả theo giải.</p>
          <b>Mở backtest →</b>
        </Link>

        <Link href="/bet-history" className="pcr-home-card">
          <span className="eyebrow">03</span>
          <h2>Audit & lịch sử</h2>
          <p>Theo dõi quyết định, settlement và lịch sử paper-bet để đánh giá hệ thống theo thời gian.</p>
          <b>Mở lịch sử →</b>
        </Link>
      </section>
    </div>
  );
}
